package System_options;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import java.awt.*; 
import javax.swing.*;
import javax.swing.border.Border;

import message.box.Message;


import java.awt.event.*; 




public class options {


	

	static String [] word_Demo;
               

	public static void man( JFrame jF,String [] word) throws IOException {
	
		word_Demo=word;
		Demo();
	
			
	}



	private static void  Demo() throws IOException 
    { 
       //---------加入文章------------------------------//
		//word_Demo
		
	
		
		
		
		
		
		
		
		
	    //-----------------------------------------------//
		// TODO Auto-generated method stub
		 JFrame JF= new JFrame();    

		    final List<Image> icons = new ArrayList<Image>();
		    
		      String imagePath = "AIS.jpg";
	         File imageFile = new File(imagePath);
		     icons.add(ImageIO.read(imageFile));
		//     JF.setBounds(100, 100, 400, 400); 
		         
		 JF.setIconImages(icons); 
		 JF.getContentPane().setBackground( new Color(243,243,243));
		 JF.setBounds(100, 100, 200, 200);
		 JF.setSize(300,200);    
		 JF.setLayout(null);    
         
         //----------------JPanel-------------------------------//
         
	     JPanel panel=new JPanel();  
	     panel.setBounds(20,30,200,150);    
	  //   JF.setContentPane(panel);
	  
	     panel.setBackground(Color.gray);  
	 	Color bgColor = new Color(243,243,243);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	 	panel.setBackground(bgColor);
		Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
		panel.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));
	     
		//---------------------------------------------//
		
		
		
		
		
		
		
	     //-----G1-------------//
	     //-------------ButtonGroup 不可複選-共體-G1--------------------------//
	     ButtonGroup   G1 = new ButtonGroup(); 
	     
	     //---------------------------------------------------//
	     JLabel   music_wise= new JLabel(word_Demo[4]); 
	     panel.add(music_wise); 	     
	     //--------------------------------//	     
	     /*     
	     JButton b1=new JButton("Button 1");     
	     b1.setBounds(50,100,80,30);    
	     b1.setBackground(Color.yellow);   
	     JButton b2=new JButton("Button 2");   
	     b2.setBounds(100,100,80,30);    
	     b2.setBackground(Color.green);   
	     panel.add(b1);
	     panel.add(b2);  
	     */

	     
	     Color GColor =bgColor;
	     
	     
	     //------共體-G1--------------------------------//   
	     JRadioButton  G1_open = new JRadioButton(); 
	     G1_open.setText(word_Demo[1]); 
	 //    jRadioButton.setBounds(120, 30, 120, 50); 
	     G1_open.setBackground(GColor);
	     panel.add(G1_open); 
	     G1.add(G1_open); 
	     
	     
	     //-----共體-G1-------------------------------//   
	     JRadioButton  G1_closure = new JRadioButton(); 
	     G1_closure.setText(word_Demo[2]); 
	 //    jRadioButton2.setBounds(250, 30, 80, 50);
	     G1_closure.setBackground(GColor);
	     panel.add(G1_closure); 
	     G1.add(G1_closure); 
	     
	     
	     //------G2----------//
	     ButtonGroup   G2 = new ButtonGroup(); 
	     //-------------------------------------//
	     JLabel  loading_window_wise= new JLabel(word_Demo[5]); 
	     
	     panel.add(loading_window_wise); 
	     //------共體-G2--------------------------------//   
	     JRadioButton  G2_open = new JRadioButton(); 
	     G2_open.setText(word_Demo[1]); 
	 //    jRadioButton.setBounds(120, 30, 120, 50); 
	     G2_open.setBackground(GColor);
	     panel.add(G2_open); 
	     G2.add(G2_open); 
	     
	     
	     //-----共體-G2-------------------------------//   
	     JRadioButton  G2_closure = new JRadioButton(); 
	     G2_closure.setText(word_Demo[2]); 
	 //    jRadioButton2.setBounds(250, 30, 80, 50);
	     G2_closure.setBackground(GColor);
	     panel.add(G2_closure); 
	     G2.add(G2_closure); 
	     
	     //-------------------------------------------//
	     
	     
	     
	     
	     
	     //------G2----------//
	     ButtonGroup   G3 = new ButtonGroup(); 
	     //-------------------------------------//
	     JLabel  tray_window_wise= new JLabel(word_Demo[7]); 
	     
	     panel.add(tray_window_wise); 
	     //------共體-G3--------------------------------//   
	     JRadioButton  G3_open = new JRadioButton(); 
	     G3_open.setText(word_Demo[1]); 
	 //    jRadioButton.setBounds(120, 30, 120, 50); 
	     G3_open.setBackground(GColor);
	     panel.add(G3_open); 
	     G3.add(G3_open); 
	     
	     
	     //-----共體-G3-------------------------------//   
	     JRadioButton  G3_closure = new JRadioButton(); 
	     G3_closure.setText(word_Demo[2]); 
	 //    jRadioButton2.setBounds(250, 30, 80, 50);
	     G3_closure.setBackground(GColor);
	     panel.add(G3_closure); 
	     G3.add(G3_closure); 
	     
	     //-------------------------------------------//
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	
	     //----獨立確認--------Click-------------------------/
	     JButton jButton   = new JButton(word_Demo[3]); 

	   //  jButton.setBounds(125, 90, 80, 30); 
	   
	     jButton.setBackground(new Color(255,255,255) );
	     panel.add(jButton);
	     
	     //-------獨立--------close----------------------/
	     
			JButton close = new JButton();
			close.setBounds(250, 0, 50, 20);
			JF.add(close);
			
			//	data.addActionListener((ActionListener) this);
			close.setText(word_Demo[0]);
			close.setFocusable(false);	
			close.setHorizontalTextPosition(close.CENTER);
			close.setVerticalTextPosition(close.BOTTOM);
			close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
			close.setIconTextGap(-20); //位置 		
			close.setForeground(Color.white);
			close.setBackground(new Color(203,0,66) );
			close.setBorder(BorderFactory.createEtchedBorder());
			JF.add(close);
	//-------------------close-------------------------------//			
	     
	 	
			close.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
					JF.dispose();
				}
			});
	     
//---------------------------jButton----Click-----------------------------------------------//	     
			 
	     
			  jButton.addActionListener(new ActionListener() { 
		            // Anonymous class. 
		  
		            public void actionPerformed(ActionEvent e) 
		            { 
		                // Override Method 
		  
		                // Declaration of String class Objects. 
		                String qual = " "; 
		                //---------music----------------//
		                // If condition to check if jRadioButton2 is selected. 
		                String op="開";
		             	String closure="關";
		             	
		             	
		                if (G1_open.isSelected()) { 
		                	
		                	
		                	Switch_options_music(op);
		                    qual = word_Demo[1]; 
		                } 
		  
		                else if (G1_closure.isSelected()) { 
		  
		            
		                	Switch_options_music(closure);
		                    qual = word_Demo[2]; 
		                } 
		                //---------loading----------------//
		                
		                if (G2_open.isSelected()) { 
		          		  
		                	Switch_options_Loading(op);
		                	
		                    qual = word_Demo[1]; 
		                } 
		  
		                else if (G2_closure.isSelected()) { 
		  
		                	Switch_options_Loading(closure);
		                	
		                    qual = word_Demo[2]; 
		                } 
		                
                     //---------loading----------------//
		                
		                if (G3_open.isSelected()) { 
		          		  

			       		     
			       		     String Key_neame ="data.wise.🗄️";

			       		     
			       		     String Key_neametray="options.txt";
			                	
			                    
			 
			    			    
			    				  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neametray)) {
			    			            writer.write("1");  // 寫入內容到文件
			    				  } catch (IOException e1) {
			    					// TODO 自動產生的 catch 區塊
			    					e1.printStackTrace();
			    				}
			    				  
		
			    						
			    			        	  
			    				        String output_HA = Key_neame+"\\"+Key_neametray;
			    				     Path path = Paths.get(output_HA);

			    				            // 创建文件，如果文件不存在
			    				            if (!Files.exists(path)) {
			    				                try {
			    									Files.createFile(path);
			    								} catch (IOException e1) {
			    									// TODO 自動產生的 catch 區塊
			    									e1.printStackTrace();
			    								}
			    				                System.out.println("文件已创建: " + path);
			    				            } else {
			    				                System.out.println("文件已经存在: " + path);
			    				            }
			    				    
			    					        
			    				            System.out.print("停滯使用\n");
			    							  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neametray)) {
			    						            writer.write("1");  // 寫入內容到文件
			    							  } catch (IOException e1) {
			    								// TODO 自動產生的 catch 區塊
			    								e1.printStackTrace();
			    							}

			    						 
			    			        	System.out.print(Key_neametray+" = 1\n");
			    				  
			    				  
			    				  
		                    qual = word_Demo[1]; 
		                } 
		  
		                else if (G3_closure.isSelected()) { 
		  
		                
		                	
		                	   
			       		     String Key_neame ="data.wise.🗄️";

			       		     
			       		     String Key_neametray="options.txt";
			                	
			                    
			 
			    			    
			    	
		
			    						
			    			        	  
			    				        String output_HA = Key_neame+"\\"+Key_neametray;
			    				     Path path = Paths.get(output_HA);

			    				            // 创建文件，如果文件不存在
			    				            if (!Files.exists(path)) {
			    				                try {
			    									Files.createFile(path);
			    								} catch (IOException e1) {
			    									// TODO 自動產生的 catch 區塊
			    									e1.printStackTrace();
			    								}
			    				                System.out.println("文件已创建: " + path);
			    				            } else {
			    				                System.out.println("文件已经存在: " + path);
			    				            }
			    				    
			    					        
			    				            System.out.print("停滯使用\n");
			    							  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neametray)) {
			    						            writer.write("0");  // 寫入內容到文件
			    							  } catch (IOException e1) {
			    								// TODO 自動產生的 catch 區塊
			    								e1.printStackTrace();
			    							}

			    						 
			    								 
					    			        	System.out.print(Key_neametray+" = 0\n");
		
					    					    
					    					    
					    					    
					    		
		                	
		                	
		                    qual = word_Demo[2]; 
		                } 
		                
		                else { 
		  
		                    qual = "NO Button selected"; 
		                } 
		           //     JOptionPane.showMessageDialog(JF, word_Demo[6]); 
		                // MessageDialog to show information selected radio buttons. 
		     
		            try {
						new Message(word_Demo[6],word_Demo[0]);
					} catch (IOException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
		        		
		        		
		            	JF.dispose();
		            } 
		        }); 
			
	//-----------------------------------------------------------------------//		
			
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			
			
			
			
			//-----------------------------------------------------//
	     JF.add(panel);
	   JF.setUndecorated(true);// 窗口去边框
		JF.setBackground(new Color(0,0,0));// 设置窗口为透明色   
	     JF.setVisible(true);            
    } 
            
           






    
	public static void  Switch_options_music(String Switch) // 存取開關
	{
		
	//music.wise.🎵
 	    
   	    File KNN = new File("music.wise.🎵");   
   	    KNN.mkdir(); 
   	    
   	    
        try {
          // create a FileWriter object with the file name
          FileWriter writer = new FileWriter("music.wise.🎵/music.txt");

          // write the string to the file
          writer.write(Switch);

          // close the writer
          writer.close();

          System.out.println("Successfully wrote text to file.");

      } catch (IOException e) {
          System.out.println("An error occurred.");
          e.printStackTrace();
      }
	
		
	}
	
	public static void  Switch_options_Loading(String Switch) // 存取開關
	{
		
	//music.wise.🎵
 	    
   	    File KNN = new File("Loading.wise.🖥️");   
   	    KNN.mkdir(); 
   	    
   	    
        try {
          // create a FileWriter object with the file name
          FileWriter writer = new FileWriter("Loading.wise.🖥️/Loading.txt");

          // write the string to the file
          writer.write(Switch);

          // close the writer
          writer.close();

          System.out.println("Successfully wrote text to file.");

      } catch (IOException e) {
          System.out.println("An error occurred.");
          e.printStackTrace();
      }
	
		
	}
	
	
	
} 