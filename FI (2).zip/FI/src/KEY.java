

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class KEY  extends JFrame {
	  private JPanel contentPane;
	    private JTextField txtId, txtPwd;
	    private JLabel lblId, lblPwd;
	    private JButton btnLogin,BtnLogin,USDT,Paypal, Return,close;
	    String    hostAddress ;
		static String Key_neame ="data.wise.🗄️";
		
	  	String ecpay_me = "https://p.ecpay.com.tw/0AA0DC9";
	  	
	  	String Paypal_me = "https://www.paypal.com/ncp/payment/JGHY5VACSQLZQ";
	  	
		
		  public static  JFrame KeyJFrame ; // 關閉先前的視窗 - >打開新的視窗
		static   nat n = new nat();   
	    
	    KEY() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
	   //------------------------------------//
	    	
			  JFrame JF = this;
		    	
	    	  JF.setTitle(AIS.System2); // 名稱
			  
	    	String [] KEY_nat =n.read_KEY();
	    	
	    	Color ColorsetBackground_AIS  = AIS.ColorsetBackground_AIS;
	
	    	
		    try {
				URL url32 = new URL("https://github.com/SuWeizhe1124/-image/blob/main/LOGO-removebg-preview%20(1).png?raw=true");
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    final List<Image> icons = new ArrayList<Image>();	    
		      String imagePath = "AIS.jpg";
	         File imageFile = new File(imagePath);
		     try {
				icons.add(ImageIO.read(imageFile));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	    
		     
		     
		  
		      this.setIconImages(icons); 

				 
	    	setResizable(false);
	        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setBounds(300, 300, 500, 240);
	  
	        
	        contentPane = new JPanel();
		 	Color bgColor = new Color(255,255,255);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
		 	contentPane.setBackground(bgColor);
		 	
	        setContentPane(contentPane);
	        
	        contentPane.setLayout(null);
/*
	        txtId = new JTextField();
	        txtId.setToolTipText("輸入你的帳號");
	        txtId.setColumns(20);
	        txtId.setBounds(100, 20, 120, 25);
	        contentPane.add(txtId);

	        */
	        txtPwd = new JTextField();
	        txtPwd.setToolTipText("輸入你的密碼");
	        txtPwd.setColumns(20);
	        txtPwd.setBounds(290, 68, 100, 16);
	        contentPane.add(txtPwd);
//----------------------------------------------------------//
	        lblId = new JLabel(KEY_nat[0]);
	        lblId.setBounds(20, 25, 1000, 15);
	           lblId.setForeground(ColorsetBackground_AIS); // 設置文字顏色為紅色
	        
	        contentPane.add(lblId);

	        
	       
	        
	        
	        lblPwd = new JLabel(KEY_nat[1]);
	        lblPwd.setBounds(20, 65, 250, 15);
	        lblPwd.setForeground(ColorsetBackground_AIS); // 設置文字顏色為紅色 Fill in the serial number and charge annually
	        contentPane.add(lblPwd);
	        

	        //---------------------------------------------//
	        btnLogin = new JButton(KEY_nat[2]);
	        btnLogin.setBounds(10, 100, 170, 25);
	        contentPane.add(btnLogin);
			//	data.addActionListener((ActionListener) this);
	        btnLogin.setText(KEY_nat[2]);
	        btnLogin.setFocusable(false);	
	        btnLogin.setHorizontalTextPosition(btnLogin.CENTER);
	        btnLogin.setVerticalTextPosition(btnLogin.BOTTOM);
	        btnLogin.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	        btnLogin.setIconTextGap(-20); //位置 		
	        btnLogin.setForeground(ColorsetBackground_AIS);
	        btnLogin.setBackground(new Color(243,243,243) );
	        btnLogin.setBorder(BorderFactory.createEtchedBorder());
				contentPane.add(btnLogin);
			
				
	     
	        
	        
	        
	        
	        
	        BtnLogin = new JButton(KEY_nat[3]);
	        BtnLogin.setBounds(190, 100, 250, 25);
	        contentPane.add(BtnLogin);
       
			//	data.addActionListener((ActionListener) this);
	        BtnLogin.setText(KEY_nat[3]);
	        BtnLogin.setFocusable(false);	
	        BtnLogin.setHorizontalTextPosition(BtnLogin.CENTER);
	        BtnLogin.setVerticalTextPosition(BtnLogin.BOTTOM);
	        BtnLogin.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	        BtnLogin.setIconTextGap(-20); //位置 		
	        BtnLogin.setForeground(ColorsetBackground_AIS);
	        BtnLogin.setBackground(new Color(243,243,243) );
	        BtnLogin.setBorder(BorderFactory.createEtchedBorder());
				contentPane.add(BtnLogin);
				
				
				
	        Paypal = new JButton(KEY_nat[4]);
	        Paypal.setBounds(190, 130, 250, 25);
	        contentPane.add(Paypal);
			//	data.addActionListener((ActionListener) this);
	        Paypal.setText(KEY_nat[4]);
	        Paypal.setFocusable(false);	
	        Paypal.setHorizontalTextPosition(Paypal.CENTER);
	        Paypal.setVerticalTextPosition(Paypal.BOTTOM);
	        Paypal.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	        Paypal.setIconTextGap(-20); //位置 		
	        Paypal.setForeground(ColorsetBackground_AIS);
	        Paypal.setBackground(new Color(243,243,243) );
	        Paypal.setBorder(BorderFactory.createEtchedBorder());
				contentPane.add(Paypal);
				
				   
				Return = new JButton(KEY_nat[12]);
				Return.setBounds(10, 130, 170, 25);
		        contentPane.add(Return);
		        Return.setText(KEY_nat[12]);
		        Return.setFocusable(false);	
		        Return.setHorizontalTextPosition(Paypal.CENTER);
		        Return.setVerticalTextPosition(Paypal.BOTTOM);
		        Return.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
		        Return.setIconTextGap(-20); //位置 		
		        Return.setForeground(ColorsetBackground_AIS);
		        Return.setBackground(new Color(243,243,243) );
		        Return.setBorder(BorderFactory.createEtchedBorder());
					contentPane.add(Return);
	
					
					
					
					/*
					
					  
					JButton close = new JButton();
					close.setBounds(450, 0, 50, 20);
					contentPane.add(close);
					
					//	data.addActionListener((ActionListener) this);
					close.setText(KEY_nat[13]);
					close.setFocusable(false);	
					close.setHorizontalTextPosition(close.CENTER);
					close.setVerticalTextPosition(close.BOTTOM);
					close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
					close.setIconTextGap(-20); //位置 		
					close.setForeground(Color.white);
					close.setBackground(new Color(203,0,66) );
					close.setBorder(BorderFactory.createEtchedBorder());
					contentPane.add(close);	
					
					*/
					
					
					
					
					
					
					
		
		 //-----------Return---------------------// 		
				Return.addActionListener(new ActionListener() {
			            public void actionPerformed(ActionEvent e) {
			            	
			          
			            	
			            	KeyJFrame.dispose();
			       
						JF.dispose();
				 try {
				 	 AIS.Muisc_option();
					new AIS();
					
				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
					// TODO 自動產生的 catch 區塊
					e1.printStackTrace();
				}
			            	
			            }
			        });
			    			    
				
				
				
				
				  //-----------btnLogin---------------------//  			
				
	        
	        btnLogin.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	               	
	            	
	        		try {
						AIS.Muisc_start();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					} // 音樂
	            	
	            	
	            	
	            	   String dateTime = DateTimeFormatter.ofPattern("MMddyyyy").format(LocalDateTime.now());
	            	   
	                   // 2021 年 12 月 24 日，下午 4:34:27
	               
	                   String time = "";
	                   
	                   time =dateTime ;

	                 int Time = Integer.parseInt(time)/2;
	                   
	                 System.out.println(Time);    
	            
	            	 String xText = Time +"";
	            	
	     
	            	 try {
	            			String Name= txtPwd.getText();
	            	       	System.out.print(Name);
						Reader (Name );
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	            	
	                if ( txtPwd.getText().equals(xText)) {
	                    JOptionPane.showMessageDialog(null, KEY_nat[11], KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
	                    File_KEY_time();
	                    int r = 0;
	                    r = (int)(Math.random()*100)+1;
	                    String Size="Size";
	                
	                    String Data = String.valueOf(r);
	                    
	                    String xize="Xize";
	                    
	             //       String data=
	    	                    
	                    		try {
									DATA(Data,Size);
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
	               
	                    try {
	                    	DATA(Data,xize);
	                    	
	                    	
	                        DATA("1","local");
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
	                    
	             
					
	             	   
	               
	                    
	                    
	                    
	                    
	                    
	                    
	                    
							try {
								
							       InetAddress localHost;
									localHost = InetAddress.getLocalHost();
						               
				                    // 获取主机名
				                    String hostName = localHost.getHostName();
				                    System.out.println("主机名: " + hostName);
				                    
				                    // 获取IP地址
				                     hostAddress = localHost.getHostAddress();
				                    System.out.println("IP地址: " + hostAddress);
				                    
								
							    String route;
						        route = "Data/";
						        String name = "SIX.txt";
							    File dir = new File(route);
						        File filename = new File(route,name);
						        System.out.println("檔案名稱 : "+name);
						        System.out.println("檔案是否存在 : "+filename.exists());
						        if(filename.exists()==true)
					               {
						        	// 讀取本地IP
						       // 	JOptionPane.showMessageDialog(null, "還未註冊過本地的電腦 ", "登入中", JOptionPane.INFORMATION_MESSAGE);
						        	
						        	
						        
						        	
						        	
					               }
						        if(filename.exists()==false)
					               {
						           	  FileWriter	fw = new FileWriter(Key_neame+"\\" + "SIX" + ".txt");
										fw.write(hostAddress);// Public\Documents
			                  			fw.flush();
			                  			System.out.println("Suweizhe -存檔到公用文件系統!");
			                  			fw.close();
						        	
					               }
						        
						        
						     
	                  			
	                  			
	                  			/*
	                  			BufferedReader reader = null;
	                
	                  			  reader = new BufferedReader(new InputStreamReader(new FileInputStream("Data\\SIX.txt"), "UTF-8")); // 指定讀取文件的編碼格式，以免出現中文亂碼
	                  			  String str = null;
	                  			  String AA = "";
	                  			  while ((str = reader.readLine()) != null) {
	                  			    System.out.println(str);
	                  			  AA=str;
	                  			  }
	                  	
	                  			   System.out.println(AA);
	 	                	
	 	                	   int AAA= Integer.valueOf(AA).intValue();
	 	                		String SIX = String.valueOf(AAA+1);
	 	                    	DATA(SIX,"SIX");
	 	                    */
	 	                    	
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
	                  		
	                  			
	                  			
//----------------------------------------------------------------------------------------------//
	                  		
	                    	
	                    	
	                    	
	                    	
	                    	
	                    	
	               
	         
	                    
	                } else {
	                    JOptionPane.showMessageDialog(null, KEY_nat[6], KEY_nat[5], JOptionPane.ERROR_MESSAGE);
	                }
	    	        
	    	
	            }
	        });
	   	 
	        //-----------BtnLogin---------------------//    
	        BtnLogin.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	           	 try {
					AIS.Muisc_option();
				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
					// TODO 自動產生的 catch 區塊
					e1.printStackTrace();
				}
	           	
	            	//String me = "https://p.ecpay.com.tw/2687370";
	    			chome(ecpay_me);
	            }
	        });
	 
	        //-----------Paypal---------------------//    
	    Paypal.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	           	 try {
					AIS.Muisc_option();
				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
					// TODO 自動產生的 catch 區塊
					e1.printStackTrace();
				}
	         	String Paypal_me = "https://www.paypal.com/ncp/payment/JGHY5VACSQLZQ";
    			chome(Paypal_me);
	            }
	        });
	    
	    //-----------close---------------------//
	    
/*
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				// System.exit(0);
		//	JF.setExtendedState(JFrame.ICONIFIED);
				JF.dispose();
			}
		});
     */
	    
	    
	    
	    
	    
	    
	    
	   //     JF.setUndecorated(true);// 窗口去边框
	 //		JF.setBackground(new Color(0,0,0));// 设置窗口为透明色   
	        setVisible(true);
	    }
	    
	 
	    
	    public static void chome(String Url) {

			String url = Url;
			// ------------------------------------------------------//

			// ------------------------------------------------------//
			try {

				java.net.URI uri = java.net.URI.create(url);
				// 獲取當前系統桌面擴充套件
				java.awt.Desktop dp = java.awt.Desktop.getDesktop();
				// 判斷系統桌面是否支援要執行的功能
				if (dp.isSupported(java.awt.Desktop.Action.BROWSE)) {
					dp.browse(uri);
					// 獲取系統預設瀏覽器開啟連結
				}
			} catch (java.lang.NullPointerException e) {
				// 此為uri為空時丟擲異常
				e.printStackTrace();
			} catch (java.io.IOException e) {
				// 此為無法獲取系統預設瀏覽器
				e.printStackTrace();
			}

			// ------------------------------------------------------//
			try {
				Thread.sleep(3000);

				// 2秒 確定網址

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 設定 兩秒後啟關閉 瀏覽器
			// -----關閉-------------------------------------------------//

		}
	    
		
		public static void Reader ( String Name) throws IOException {
			String [] KEY_nat =n.read_KEY();
			
	    String route;
        route = Key_neame+"/";
        String name = "size.txt";
	    File dir = new File(route);
        File filename = new File(route,name);
        System.out.println("檔案名稱 : "+name);
        System.out.println("檔案是否存在 : "+filename.exists());
        System.out.println(Name);
               if(filename.exists()==false)
               {
            	   JOptionPane.showMessageDialog(null, KEY_nat[9],KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
            	   
            	   
            	   /*
           		        FileWriter fw = new FileWriter("Data\\" + "SIX" + ".txt");
            		//	fw.write(0);// Public\Documents
            			fw.flush();
            			System.out.println("Suweizhe -存檔到公用文件系統!");
            			// After used close.
            			fw.close();
            			
            			*/
            			
               }
               if(filename.exists()==true)
               {

            	   
            	   

            	   String Size = ""; 
            	   String size = ""; 
            	   FileReader fr = new FileReader(Key_neame+"\\"+"Size.txt");
            	   BufferedReader br = new BufferedReader(fr);

            	   while (br.ready()) {
            	   	System.out.println(br.readLine());
            	   	Size=br.readLine();
            	   }
            	   fr.close();
            	   
            	   
            	   
            	   
              	   FileReader Fr = new FileReader(Key_neame+"\\Xize.txt");
            	   BufferedReader Br = new BufferedReader(Fr);

            	   while (Br.ready()) {
            	   	System.out.println(Br.readLine());
            	 	size=Br.readLine();
            	   }
            	   Fr.close();
            	   
            	   if(size==Size)
            	   {
            		   
            		   JOptionPane.showMessageDialog(null, KEY_nat[7], KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
            		   
            		   
            		    InetAddress localHost;
						localHost = InetAddress.getLocalHost();
			               
	                    // 获取主机名
	                    String hostName = localHost.getHostName();
	                    System.out.println("主机名: " + hostName);
	                    
	                    // 获取IP地址
	                    String hostAddress = localHost.getHostAddress();
	                    System.out.println("IP地址: " + hostAddress); 
	              
	                    FileWriter	fw = new FileWriter(Key_neame+"\\" + "SIX2" + ".txt");
						fw.write(hostAddress);// Public\Documents
              			fw.flush();
              			System.out.println("Suweizhe -存檔到公用文件系統!");
              			fw.close();
	                    
              			
              			
              		      BufferedReader reader = null;
     	              
	                      reader = new BufferedReader(new InputStreamReader(new FileInputStream(Key_neame+"\\" + "SIX2" + ".txt"), "UTF-8")); // 指定讀取文件的編碼格式，以免出現中文亂碼
	                      String str = null;
	                      while ((str = reader.readLine()) != null) {
	                        System.out.println(str);
	
	                      }
              			
	                    
	                    BufferedReader Reader = null;
	              
	                    Reader = new BufferedReader(new InputStreamReader(new FileInputStream(Key_neame+"\\" + "SIX" + ".txt"), "UTF-8")); // 指定讀取文件的編碼格式，以免出現中文亂碼
	                      String Str = null;
	                      while ((Str = Reader.readLine()) != null) {
	                        System.out.println(Str );
	
	                      }
	           
            		   if(Str==str) {
            			   
            			   
            			   JOptionPane.showMessageDialog(null, KEY_nat[8], KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
            			   
            	             FileWriter	w = new FileWriter(Key_neame+"\\" + "local" + ".txt");
     						w.write("1");// Public\Documents
                   			w.flush();
                   			System.out.println("Suweizhe -存檔到公用文件系統!");
                   			w.close();
            		   }
            		   else
            		   {
            			   JOptionPane.showMessageDialog(null, KEY_nat[9], KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
               		          FileWriter	w = new FileWriter(Key_neame+"\\" + "local" + ".txt");
    						w.write("0");// Public\Documents
                  			w.flush();
                  			System.out.println("Suweizhe -存檔到公用文件系統!");
                  			w.close();
            		   }
            		   
            	   }else
            	   {
            		   JOptionPane.showMessageDialog(null,KEY_nat[10], KEY_nat[5], JOptionPane.INFORMATION_MESSAGE);
            		    FileWriter	w = new FileWriter("Data\\" + "local" + ".txt");
 						w.write("0");// Public\Documents
               			w.flush();
               			System.out.println("Suweizhe -存檔到公用文件系統!");
               			w.close();
            	   }
            	   
            	
               }
               
         
               
		}
		public static void DATA(String data, String namedata) throws IOException {
			
		
			FileWriter fw = new FileWriter(Key_neame+"\\" + namedata + ".txt");
			fw.write(data);// Public\Documents
			fw.flush();
			System.out.println("Suweizhe -存檔到公用文件系統!");
			// After used close.
			fw.close();

		}



		public void Frame(JFrame jF) {
	
			KeyJFrame= jF;
			
		}

	    
	    public static void File_KEY_time() {
	    	
	    	
	    	
	        String yyyy = DateTimeFormatter.ofPattern("yyyy").format(LocalDateTime.now());//開始購買日期
	        
	        String MM = DateTimeFormatter.ofPattern("MM").format(LocalDateTime.now());//開始購買日期
	        
	        String dd = DateTimeFormatter.ofPattern("dd").format(LocalDateTime.now());//開始購買日期
	        
	   
	        int Time_365_years = (Integer.parseInt(yyyy))+1; // 計算好年份 存檔
	        String sStr = String.valueOf(Time_365_years);
	        
	   

	  
	        
	        String Time_365 = String.valueOf( date_converter(sStr,MM,dd));// 計算好年份 存檔
	        
	        String output_HA =  Key_neame+"\\"+"input_HA.txt";
	        FileWriterTXT(output_HA,Time_365); //當下存檔 現有的日期 以及以後的日期
	        
	        
	       
	        
	        

	        
	    //-------------------------------------------------------------------//
	        
	   
	        
	    }
	    
	    public static boolean read_KEY_time() {
	    	
	   
	        
	      String yyyy = DateTimeFormatter.ofPattern("yyyy").format(LocalDateTime.now());//開始購買日期
	        
	        String MM = DateTimeFormatter.ofPattern("MM").format(LocalDateTime.now());//開始購買日期
	        
	        String dd = DateTimeFormatter.ofPattern("dd").format(LocalDateTime.now());//開始購買日期
	        
	        
	        int str_365 =date_converter(yyyy,MM,dd);
	        
	        String output_HA = Key_neame+"\\"+"input_HA.txt";
	        
	        String   KEY365 =BufferedReaderTXT(output_HA);
	       if(KEY365=="")
	       {
	    	   
	    	   KEY365="0";
	       }
	        
	        int Time_365_years = (Integer.parseInt( KEY365));
	        
	        int KEY_time=(Time_365_years-str_365);
	        
	       // System.out.println("該續約了 "+KEY_time);  // 每次讀取一行並輸出

	        
	        boolean isTrue = false;  // 声明一个布尔类型变量并赋值为 true
	    
	    	if(KEY_time<=0)
	    	{
	    		

	    	     isTrue = false;
	    	      
	    	}else
	    	{
	    		  System.out.println("已續約了 剩下"+KEY_time+"天");  // 每次讀取一行並輸出
	    		
	    		isTrue = true;
	    	}

	    	
	    	
	    	
			return isTrue;
	    	
	    }
	    
	    public static int  date_converter(String year ,String month ,String data) {

	    	int year_  =Integer.parseInt(year);
	    	
	    	
	        int month_  =Integer.parseInt(month);
	    	
	 //--------------------------------------------------//

	        
	        
	        int year_data = year_*365;//該年分天數
	        
	        int daysInMonth = getDaysInMonth(year_, month_);//該月天數  
	        
	        int data_  =Integer.parseInt(data);//現今年今月日期
	        
	    	
			return  year_data+daysInMonth+data_;
	    	
	    }
	    
	    public static int getDaysInMonth(int year, int month) {
	        // 每個月的天數，從 1 月到 12 月
	        int[] daysInMonths = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	        // 檢查是否為閏年，並處理 2 月
	        if (month == 2 && isLeapYear(year)) {
	            return 29;  // 閏年 2 月
	        }
	        return daysInMonths[month - 1];  // 返回指定月份的天數
	    }

	    // 判斷是否為閏年
	    public static boolean isLeapYear(int year) {
	        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
	            return true;  // 閏年
	        }
	        return false;  // 非閏年
	    }

	    
	    public static void FileWriterTXT(String name,String set) {
	    
	   

	        try (FileWriter writer = new FileWriter(name)) {
	            writer.write(set);  // 寫入內容到文件

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public static String  BufferedReaderTXT(String name) {

	        String ste = "";
	        try (BufferedReader reader = new BufferedReader(new FileReader(name))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                System.out.println("line = "+line);  // 每次讀取一行並輸出
	                ste=line;
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
			return ste;
	        
	       
	    }
}
