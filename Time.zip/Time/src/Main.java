import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;
import java.util.Date;
 

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
 
public class Main {
	
	
	
	
    public static void main(String[] args) {
        String dateTime = DateTimeFormatter.ofPattern("MMddyyyy").format(LocalDateTime.now());
        		//
 
        // 2021 年 12 月 24 日，下午 4:34:27
    
        String time = "";
        
        time =dateTime ;

      int Time = Integer.parseInt(time)/2; //key 

	     System.out.println(Time);  // 每次讀取一行並輸出
      //-------------------再續約KEY-------------//
        
  /*   購買後存檔     
   * 現有的時間的日期
   *   轉換日期
   * 
   * 
   * 
   * 
   *    
   * */
      File_KEY_time(); // 購買後
      
      /*   讀取存檔    辨識現有的時間跟之前的時間差有沒有一年的日期
       *   轉換日期
       * 
       * 
       * 
       * 
       *    
       * */
      read_KEY_time();
    }
    
    
    public static void File_KEY_time() {
    	
    	
    	
        String yyyy = DateTimeFormatter.ofPattern("yyyy").format(LocalDateTime.now());//開始購買日期
        
        String MM = DateTimeFormatter.ofPattern("MM").format(LocalDateTime.now());//開始購買日期
        
        String dd = DateTimeFormatter.ofPattern("dd").format(LocalDateTime.now());//開始購買日期
        
   
        int Time_365_years = (Integer.parseInt(yyyy))+1; // 計算好年份 存檔
        String sStr = String.valueOf(Time_365_years);
        
   

  
        
        String Time_365 = String.valueOf( date_converter(sStr,MM,dd));// 計算好年份 存檔
        
        String output_HA = "input_HA.txt";
        FileWriterTXT(output_HA,Time_365); //當下存檔 現有的日期 以及以後的日期
        
        
       
        
        

        
    //-------------------------------------------------------------------//
        
   
        
    }
    
    public static boolean read_KEY_time() {
    	
   
        
      String yyyy = DateTimeFormatter.ofPattern("yyyy").format(LocalDateTime.now());//開始購買日期
        
        String MM = DateTimeFormatter.ofPattern("MM").format(LocalDateTime.now());//開始購買日期
        
        String dd = DateTimeFormatter.ofPattern("dd").format(LocalDateTime.now());//開始購買日期
        
        
        int str_365 =date_converter(yyyy,MM,dd);
        
        String output_HA = "input_HA.txt";
        
        String   KEY365 =BufferedReaderTXT(output_HA);
 
        
        int Time_365_years = (Integer.parseInt( KEY365));
        

        int KEY_time=(Time_365_years-str_365);
        


        
        boolean isTrue = false;  // 声明一个布尔类型变量并赋值为 true
    
    	if(KEY_time<=0)
    	{
    		
    	     System.out.println("該續約了 "+KEY_time);  // 每次讀取一行並輸出
    	     isTrue = false;
    	      
    	}else
    	{
    		
    		  System.out.println("已續約了 剩下"+KEY_time+"天");  // 每次讀取一行並輸出
    		isTrue = true;
    	}

    	
    	
    	
		return isTrue;
    	
    }
    
    public static int  date_converter(String year ,String month ,String data) {

    	int year_  =Integer.parseInt(year);
    	
    	
        int month_  =Integer.parseInt(month);
    	
 //--------------------------------------------------//

        
        
        int year_data = year_*365;//該年分天數
        
        int daysInMonth = getDaysInMonth(year_, month_);//該月天數  
        
        int data_  =Integer.parseInt(data);//現今年今月日期
        
    	
		return  year_data+daysInMonth+data_;
    	
    }
    
    public static int getDaysInMonth(int year, int month) {
        // 每個月的天數，從 1 月到 12 月
        int[] daysInMonths = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        // 檢查是否為閏年，並處理 2 月
        if (month == 2 && isLeapYear(year)) {
            return 29;  // 閏年 2 月
        }
        return daysInMonths[month - 1];  // 返回指定月份的天數
    }

    // 判斷是否為閏年
    public static boolean isLeapYear(int year) {
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            return true;  // 閏年
        }
        return false;  // 非閏年
    }

    
    public static void FileWriterTXT(String name,String set) {
    
   

        try (FileWriter writer = new FileWriter(name)) {
            writer.write(set);  // 寫入內容到文件

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String  BufferedReaderTXT(String name) {

        String ste = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(name))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("line = "+line);  // 每次讀取一行並輸出
                ste=line;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		return ste;
        
       
    }
}
