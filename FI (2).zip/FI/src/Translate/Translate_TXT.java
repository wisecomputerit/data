package Translate;

import java.awt.datatransfer.Transferable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

import System_options.options;

public class Translate_TXT {

	
	
	
	private static String main_flie_name ="article.wise.📑/";
	
	
	
	
	
	private static String flie_name ="article.wise.📑/English/";
	
	private static String main_class = "main.txt";
	
	private static String nation_class ="nation.txt";

	public  static void main( ) {
		
	
		 Translate_class_file_TOpath(class_path());
		
		//  Translate_file_class(	Translate_class()	 );
		
		
	
	}
	
	
	public  static   void  Translate_class_file_TOpath(  String[] array) 
	{
		 // 指定要創建的資料夾路徑
            for(int i=0;i<array.length;i++) {
			
			
            	Translate_class_file_path(array[i]);
			
		}
		
		
	}
	
	
	public  static   void  Translate_class_file_path(String name) 
	{
		 // 指定要創建的資料夾路徑
        String folderPath = main_flie_name+name;

        // 建立 File 對象
        File folder = new File(folderPath);

        // 檢查資料夾是否存在，若不存在則創建
        if (!folder.exists()) {
            if (folder.mkdir()) {
                System.out.println("資料夾創建成功：" + folderPath);
            } else {
                System.out.println("資料夾創建失敗。");
            }
        } else {
            System.out.println("資料夾已存在：" + folderPath);
        }
		
		
	}

	
	public  static    String[]   class_path() 
	{
	
		   // 指定要讀取的文件路徑
        String filePath =flie_name +nation_class; // 請確保文件存在於此路徑
        
        // 使用 ArrayList 來動態存儲讀取的數據
        java.util.ArrayList<String> list = new java.util.ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // 按行讀取文件
            while ((line = br.readLine()) != null) {
                list.add(line); // 將每一行添加到列表中
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 將 ArrayList 轉換為字串陣列
        String[] array = list.toArray(new String[0]);
          
        Arrays.sort(array);
        
        // 輸出字串陣列的內容
        System.out.println("讀取的資料轉換為字串陣列：");
        for (String item : array) {
            System.out.println(item);
        }
        
       // System.out.println("排序後的字母陣列（忽略大小寫）: " +   );
        
   
		return array;
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private  static    String[]   Translate_class() 
	{
	
		   // 指定要讀取的文件路徑
        String filePath =flie_name +main_class; // 請確保文件存在於此路徑
        
        // 使用 ArrayList 來動態存儲讀取的數據
        java.util.ArrayList<String> list = new java.util.ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // 按行讀取文件
            while ((line = br.readLine()) != null) {
                list.add(line); // 將每一行添加到列表中
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 將 ArrayList 轉換為字串陣列
        String[] array = list.toArray(new String[0]);
          
     
        
        // 輸出字串陣列的內容
        System.out.println("讀取的資料轉換為字串陣列：");
        for (String item : array) {
            System.out.println(item);
        }
        
       // System.out.println("排序後的字母陣列（忽略大小寫）: " +   );
        
   
		return array;
	}
	
	
	
	
	private  static void Translate_file_class(String[] class_txt)
	{
		
		
		
		for(int i=0;i<class_txt.length;i++) {
			
			
			file_class(class_txt[i]);
			
		}
		
	}
	
	
	private  static void file_class(String name) {
		
		
		// TODO 自動產生的方法 Stub
	     // 指定要創建的 TXT 文件的名稱和路徑
       String filePath = flie_name+name+".txt"; // 如果想要存放在特定目錄，可以指定完整路徑

       // 創建文件對象
       File file = new File(filePath);
       try {
           // 使用 FileWriter 和 BufferedWriter 創建文件並寫入內容
           BufferedWriter writer = new BufferedWriter(new FileWriter(file));
           writer.write("Hello, this is a sample text file!");
           writer.newLine(); // 換行
           writer.write("This file is created using Java.");
           writer.close(); // 關閉寫入流

           System.out.println("File created successfully: " + file.getAbsolutePath());
       } catch (IOException e) {
           System.err.println("An error occurred while creating the file.");
           e.printStackTrace();
       }
       
		
	}
	

}
