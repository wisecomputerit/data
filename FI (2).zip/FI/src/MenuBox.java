
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import message.box.Message;

//---拖住按鈕移動//
public class MenuBox extends JFrame implements MouseListener, MouseMotionListener {
           


	JButton button2= new JButton("close");
		JButton button1= new JButton();
		
		JButton button0= new JButton();
		
	  JPanel panel=new JPanel();  
	  
	    JLabel   music_wise2= new JLabel( ); 
	    
	    static JFrame JFJF;
int x0, y0;
int x3,y3;//记录鼠标拖动之前原来的鼠标位置的东东

       static String getMenuBox;
  
       static String return_name;
       
public static void OKMenuBox(String name)
{
	return_name=name;
	

}
       

public  MenuBox(String [] it,String OK,String Cancle,String close,String title,String All,Color color) throws IOException {
	
	String NNNNNN;

      button0.setText(OK);
	button1.setText(Cancle);

	button2.setText(close);
    JLabel   music_wise= music_wise2;

	

	 JFrame JF= this;  		
		
	 JFJF=JF;
	    //-----------------------------------------------//
		// TODO Auto-generated method stub
		
	 /*
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
       File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	     
	     JF.setIconImages(icons); 
	     
	     */
		 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

		 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
		 JF. setLayout(new FlowLayout());
		 JF.setTitle("java");
		 
		
		//     JF.setBounds(100, 100, 400, 400); 
		         
//		 JF.setIconImages(icons); 
//		 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//		 JF.setBounds(300, 200, 200, 200);
//		 JF.setSize(250,130);    
		 JF.setLayout(null);    
			java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	     //----------------JPanel-------------------------------//
			
			int width = ((scr_size.width - 300/2) / 2);
			
			int height = ((scr_size.height - 150/2)/2);
			
			
			int setpanelwidth=110;
	   
			int setpanelheight=120;
		
	     panel.setBounds(width-20-setpanelwidth/2,height-setpanelheight/2,300/2+20+setpanelwidth,(150/2)+setpanelheight);    
	 //    JF.setContentPane(panel);
	     panel.setBackground(Color.gray);  
	 	Color bgColor = new Color(243,243,243);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	 	panel.setBackground(bgColor);
		Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
		panel.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));
		
		panel.setLayout(null);
		
		//--------------------//
		

		   //  music_wise2.setForeground(new Color(254,186,41)); // 設置文字顏色

 	
		
	     int W=50;
	     int H=20;
	     
	
	     Arrays.sort(it); // 先排序


		
		 //    add(music_wise2, BorderLayout.CENTER);
		//---------------------------------------------//
	      // 创建菜单栏
        JMenuBar menuBar = new JMenuBar();

        // 创建“文件”菜单
	    JMenu fileMenu = new JMenu(it[0]);
        
     
        // 菜单项的数组
        String[] menuItems =it;
	  
      
        
  
        music_wise.setBounds(width-50, height-H-60, 250, 150); 
	     music_wise.setHorizontalAlignment(SwingConstants.CENTER); // 居中显示文字
	     music_wise.setForeground(Color.BLACK);  
	     JF.add(music_wise); 
	     music_wise.setText(title);
	     music_wise.revalidate();
	     music_wise.repaint();
	     
	     
	  
	     
	  
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	   String name = null;
        // 动态创建菜单项并添加到“文件”菜单
        for (String item : menuItems) {
            JMenuItem menuItem = new JMenuItem(item);

            // 设置菜单项像按钮一样的行为
            menuItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
             
                  //      JOptionPane.showMessageDialog(null, item + " menu item clicked");
                    	
              
                    
                    music_wise.revalidate();   // 刷新显示
           	     music_wise.repaint();

                    	   
                    	  // setMenuBox_return=item;
           	 
                    	   
                    	   getMenuBox=item;
          
                    //	   fey(item);
                    	      fileMenu.setText(item);
                    	  
                    	 System.out.print(getMenuBox);
                }
                
            });
            
            fileMenu.add(menuItem);
       
        }
        
        
      //  System.out.print("getMenuBox = "+getMenuBox+"\n");
        
  
        
  //---------------------------------------------------------------------------------//      
        

        
        

    	//-------------------------版本使用--------------------------------------///     
    	     char[] firstLetter  = new char [menuItems.length];
    	     for(int i=0;i<menuItems.length;i++)
    	     {    // 獲取字符串中的第一個字母
    		        firstLetter[i] = menuItems[i].charAt(0);
    	     }
    	
    	  

    		     // 創建一個 String[] 陣列，大小與 charArray 相同
    		        String[] stringArray = new String[firstLetter.length];

    		        // 遍歷 charArray 並將每個字符轉換為 String 陣列
    		        for (int i = 0; i < firstLetter.length; i++) {
    		            stringArray[i] = String.valueOf(firstLetter[i]);  // 將字符轉換為字符串
    		        }
    		         
    	      
    	        JMenu editMenu = new JMenu(stringArray[0]);//輸入
    //-----------------------------------------------------------//	        
    	  
    	        ArrayList<String> list = new ArrayList<>();
    	        
    	        for (int i = 0; i < firstLetter.length; i++) {
    	            // 只顯示與前一個字母不同的字母
    	            if (i == 0 || firstLetter[i] != firstLetter[i - 1]) {
    	         //  
    	            	
    	            //    System.out.print(" firstLetter "+firstLetter[i]+"\n");
    	            //	   System.out.print(  "j "+j);
    	    
    	               // arry[i]= String.valueOf(firstLetter[i]); 
    	                list.add(String.valueOf(firstLetter[i]));
    	            }
    	        }
    	        
    	        String[] array = new String[list.size()+1];
    	        array = list.toArray(array);
    	
    	        String[] editMenuItems = array;  // 輸入
    	  //---------------------------------------------------------------//      
    	        editMenuItems[list.size()]=All;
    	        
    	        
    	        // 為編輯菜單創建選單項目
    	        for (String item : editMenuItems) {
    	            JMenuItem menuItem = new JMenuItem(item);
    	            
    	            // 為每個選項添加事件處理器
    	            menuItem.addActionListener(new ActionListener() {
    	                public void actionPerformed(ActionEvent e) {
    	         
    	                	//JOptionPane.showMessageDialog(JF, "你選擇了編輯操作: " + item);
    	                    
    	                	editMenu.setText(item);
    	                    
    	                    
    	                    // 創建一個 ArrayList 用來保存以 "B" 開頭的字串
    	                    ArrayList<String> filteredWords = new ArrayList<>();

    	                    // 使用 for 迴圈篩選字串
    	                    for (String word : it) {
    	                        // 檢查字串是否以 "B" 開頭 (忽略大小寫)
    	                        if (word.startsWith(item)) {
    	                            filteredWords.add(word);
    	                        }
    	                    }

    	                    // 輸出結果
    	                    String [] letter = new String[filteredWords.size()];
    	                 //   System.out.println("以 'B' 開頭的字串有:");
    	                    int i=0;
    	                    for (String word : filteredWords) {
    	                        System.out.println("word = "+word+"\n");
    	                    
    	                        letter[i]=word;
    	                        i++;
    	               
    	                        
    	                    }
    	                    
    	                    if(item==All)
    	                    {
    	                        // 移除所有現有菜單項目
        	                    fileMenu.removeAll();
        	                    
        	                    fileMenu.setText(menuItems[0]);
        	                    getMenuBox=menuItems[0];
        	                    
        	                    // 动态创建菜单项并添加到“文件”菜单
        	                    for (String item : menuItems) {
        	                        JMenuItem menuItem = new JMenuItem(item);

        	                        // 设置菜单项像按钮一样的行为
        	                        menuItem.addActionListener(new ActionListener() {
        	                            @Override
        	                            public void actionPerformed(ActionEvent e) {
        	                         
        	                              //      JOptionPane.showMessageDialog(null, item + " menu item clicked");
        	                                	
        	                       
        	                                
        	                                music_wise.revalidate();   // 刷新显示
        	                       	     music_wise.repaint();

        	                                	   
        	                                	  // setMenuBox_return=item;
        	                                	   
        	                                	   getMenuBox=item;
        	                            
        	                                  System.out.print(getMenuBox+"\n");
        	                                	      fileMenu.setText(item);
        	                                	      
        	                                	      // 重新刷新菜單條
        	                  	                    fileMenu.revalidate();
        	                  	                    fileMenu.repaint();    
        	                             
        	                            }
        	                            
        	                        });
        	                        
        	                        fileMenu.add(menuItem);
        	                    }
        	                    
        	                    
        	                    
        	                   
        	                    
        	                    
        	                    
        	                    
    	                    	
    	                    }else
    	                    {
    	                        // 移除所有現有菜單項目
        	                    fileMenu.removeAll();
        	                    
        	                    fileMenu.setText(letter[0]);
        	                    getMenuBox=letter[0];
        	                    
        	                    
        	                    
        	                    // 动态创建菜单项并添加到“文件”菜单
        	                    for (String item : letter) {
        	                        JMenuItem menuItem = new JMenuItem(item);

        	                        // 设置菜单项像按钮一样的行为
        	                        menuItem.addActionListener(new ActionListener() {
        	                            @Override
        	                            public void actionPerformed(ActionEvent e) {
        	                            	
        	                            	
        	                         
        	                              //      JOptionPane.showMessageDialog(null, item + " menu item clicked");
        	                                	
        	                          
        	                                
        	                                music_wise.revalidate();   // 刷新显示
        	                       	     music_wise.repaint();

        	                                	   
        	                                	  // setMenuBox_return=item;
        	                                	   
        	                                	   getMenuBox=item;
        	                            
        	                                  System.out.print(getMenuBox+"\n");
        	                                	    
        	                                  fileMenu.setText(item);
        	                                	  
        	                                	    
        	                             
        	                            }
        	                            
        	                        });
        	                        
        	                        fileMenu.add(menuItem);
        	                    }
        	                    
        	                    // 重新刷新菜單條
        	                    fileMenu.revalidate();
        	                    fileMenu.repaint();
        	                    
    	                    	
    	                    	
    	                    }
    	             
    	                    
    	                }
    	            });
    	            // 添加到編輯菜單
    	            editMenu.add(menuItem);
    	        }

    	        // 將編輯菜單添加到菜單欄
    	        menuBar.add(editMenu);
    	     
        
        //------------------------------------------------------------//
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       // panel.setBounds(width-20-setpanelwidth,height-setpanelheight,300/2+20+setpanelwidth,(150/2)+setpanelheight); 

       // replaceMenu(menuBar, fileMenu, getMenuBox);
        
        fileMenu.setPreferredSize(new Dimension(150, 20));  // 设置宽度500，高度
        
    //    menuBar.setToolTipText(getMenuBox);  // 更改菜单的名称
        
        
        
      // 将“文件”菜单添加到菜单栏
        menuBar.add(fileMenu); 
        
        // 设置菜单栏
        setJMenuBar(menuBar);

        panel.add(menuBar);
        
        panel.setLayout(new BorderLayout());

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridBagLayout());  // 设置 GridBagLayout

        // 创建 GridBagConstraints 对象
        GridBagConstraints gbc = new GridBagConstraints();
        
        // 设置 gbc 用于菜单栏的位置
        gbc.gridx = 0; // 设定列
        gbc.gridy = 0; // 设定行
        gbc.gridwidth = 1; // 水平方向占一格
        gbc.gridheight = 1; // 垂直方向占一格
        gbc.fill = GridBagConstraints.HORIZONTAL;  // 水平方向拉伸

        // 添加菜单栏到面板
        menuPanel.add(menuBar, gbc);

        // 将菜单面板添加到主面板的顶部
        panel.add(menuPanel, BorderLayout.CENTER);
        
     
        

        // 将 JPanel 放入 JScrollPane，使其具有滚动条
 /*       JScrollPane scrollPane = new JScrollPane(menuPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
*/
        // 将 JScrollPane 添加到窗口的顶部
     //   panel.add(scrollPane, BorderLayout.NORTH);
        
    //----------------------------------------------//
        

	
	    
        
        
		

	     
	     
        
        
        
        

	     //----獨立確認--------Click-------------------------/
	  //   JButton jButton   = new JButton("Click"); 

		button1.setBounds(width+100-10, height+80, 50, 20); 
	     JF.add(button1);
	  //   jButton.setBackground(new Color(203,0,66));   
	     button1.setFocusable(false);	
	     button1.setHorizontalTextPosition(button1.CENTER);
	     button1.setVerticalTextPosition(button1.BOTTOM);
	     button1.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	     button1.setIconTextGap(-20); //位置 		
	     button1.setForeground(Color.white);
	     button1.setBackground(color );
	     button1.setBorder(BorderFactory.createEtchedBorder());
	     JF.add(button1);
	     
	     
	     //-------------------------------------------//
	     
	 	button0.setBounds(width-10, height+80, 50, 20); 
	     JF.add(button0);
	  //   jButton.setBackground(new Color(203,0,66));   
	     button0.setFocusable(false);	
	     button0.setHorizontalTextPosition(button1.CENTER);
	     button0.setVerticalTextPosition(button1.BOTTOM);
	     button0.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	     button0.setIconTextGap(-20); //位置 		
	     button0.setForeground(Color.white);
	     button0.setBackground(color );
	     button0.setBorder(BorderFactory.createEtchedBorder());
	     JF.add(button0);
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     //-------獨立--------close----------------------/
	     
	  //   JButton button2 = new JButton();
	     button2.setBounds(width+165, height-60, 40, 18);
			JF.add(button2);
			
			//	data.addActionListener((ActionListener) this);
	//		button2.setText("close");
			button2.setFocusable(false);	
			button2.setHorizontalTextPosition(button2.CENTER);
			button2.setVerticalTextPosition(button2.BOTTOM);
			button2.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
			button2.setIconTextGap(-20); //位置 		
			button2.setForeground(Color.white);
			button2.setBackground(color );
			button2.setBorder(BorderFactory.createEtchedBorder());
			JF.add(button2);
			//---------------------//
			
			System.out.print("\n");
			

			button0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
			       
				      String name_n=getMenuBox;
		                 
					
					if(getMenuBox==null) // 我沒有任何動作直接按鈕 所以自動幫我叛為 第一個系統
					{
						name_n =menuItems[0];
						
						System.out.print("menuItems[0 menuItems[0] menuItems[0] menuItems[0] menuItems[0] menuItems[0]  "+menuItems[0]);
						 try {
								getMenuBox(return_name);
							} catch (IOException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
						/*
						try {
							getMenuBox();
						} catch (IOException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
				*/
						
						
					}
					
					return_name=name_n;
					 System.out.print("GGGGGGGGGGGGGGGGetMenuBox = "+name_n+"\n");
					 
					 try {
						getMenuBox(return_name);
					} catch (IOException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					
					
 
					if(return_name=="")
					{
						return_name =menuItems[0];
						 try {
								getMenuBox(return_name);
							} catch (IOException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
					}
					
			
			
		
					 
					  /*
					main_min A= new main_min();
					try {
						
						A.man();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
							| InterruptedException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					*/
					Run_class_fashion();
					
					String in3="";
					MenuBox.OKMenuBox(in3);
					
					JFJF.dispose();

					 JF.dispose();
			
				
					
					/*
					
				
					
					
					
			
					 */
				}
			});
	//--------------------------------------------------//			
	     
	 	
			button2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
					
					try {
						AIS.main_option();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					JF.dispose();
				}
			});
	     
	//---------------------------jButton----Click-----------------------------------------------//	     
			 
	     
			button1.addActionListener(new ActionListener() { 
		            // Anonymous class. 
		  
		            public void actionPerformed(ActionEvent e) 
		            { 
		                // Override Method 
		  
		                // Declaration of String class Objects. 
		            	
		            	try {
							AIS.main_option();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
		            	
		                String qual = " "; 
		                //---------music----------------//
		                // If condition to check if jRadioButton2 is selected. 
		                String op="開";
		             	String closure="關";
		             	
		             	
		       
		                // MessageDialog to show information selected radio buttons. 
		            	JF.dispose();
		            } 
		        }); 
			
	//-----------------------------------------------------------------------//		
			
			  
			
			//-----------------------------------------------------//
	   
	


/*


button1.setBackground(Color.gray);  
Color bgColor = new Color(70,165,165);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
button1.setBackground(bgColor);
Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
button1.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));

*/


			panel.addMouseListener(this);
			panel.addMouseMotionListener(this);//添加监视器

			
			
			
setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

setUndecorated(true);// 窗口去边框
setBackground(new Color(0,0,0,0));// 设置窗口为透明色   

add(panel);
setVisible(true);
setResizable(false);//设置大小不可调节




}



public void mouseEntered(MouseEvent e) {}

public void mouseReleased(MouseEvent e) {}






public void mousePressed(MouseEvent e){//记录鼠标拖动之前原来的鼠标位置的东东
x3 = e.getX();
y3 = e.getY();
}




public void mouseClicked(MouseEvent e) {}





public void mouseExited (MouseEvent e) {}

         public void mouseDragged(MouseEvent e) {
        	 
       	  x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int x1=button1.getBounds().x;// 获取按钮坐标
       	  int y1 = button1.getBounds().y;
       	  button1.setLocation(x0 + x1 - x3, y0 + y1 - y3);

       	  
       	  
       	  int X1=button2.getBounds().x;// 获取按钮坐标
       	  int Y1 = button2.getBounds().y;
       	  button2.setLocation(x0 + X1 - x3, y0 + Y1 - y3);
       	  
       	  
     	  
       	  int X1X=button0.getBounds().x;// 获取按钮坐标
       	  int Y1Y = button0.getBounds().y;
       	  button0.setLocation(x0 + X1X - x3, y0 + Y1Y - y3);
       	  
       	  
          	  
          x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int XX1=panel.getBounds().x;// 获取按钮坐标
       	  int YY1 = panel.getBounds().y;
       	  panel.setLocation(x0 + XX1 - x3, y0 + YY1 - y3);
       	  

       	  
       	  
          x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int XXX1=music_wise2.getBounds().x;// 获取按钮坐标
       	  int YYY1 = music_wise2.getBounds().y;
       	music_wise2.setLocation(x0 + XXX1 - x3, y0 + YYY1 - y3);
       	  
       	  
       

}

         public void mouseMoved(MouseEvent e) {}
         
         public static String  getMenuBox(String Name) throws IOException {
        		
        		String name =Name;
        		if(name==null)
        		{
        			name="";
        		}
        
        		return name;
        	}   
         

public static  void MenuBox_fashion ( ) {
	String name="";
	return_name=name;

	
}
public static  String MenuBoxfashion (String Same) {

	
          return_name =Same;
	
	return return_name;
}

public static String  setMenuBox(String [] it,String OK,String Cancle,String close,String title,String All,
		Color color,String Class ,String e) throws IOException {
	
       //        	Color color=new Color(203,0,66);
      //          String[] menuItems = {"Open", "Save", "Close", "Exit"};
	
	                 getMenuBox="";
                  new MenuBox(it,OK,Cancle,close,title,All,color);// GA
	
                 System.out.print("setMenuBox = " +getMenuBox(return_name)+"\n");

                 inputclass_fashion (Class,e );
                  
                // JFJF
                 return getMenuBox(return_name);

}

public static	String Classname;
public static String Class_fashion;


public static  void inputclass_fashion (String Class ,String e ) {
	
Classname=Class;
Class_fashion =e;
	
}





public static void Run_class_fashion( ) {
	  try {
		  
		  
		  
		  
		  
	        // 这里替换为你自己的类名（没有包名）
	        String className = Classname;  // 不需要加包名
	        
	        // 使用 Class.forName() 获取 Class 对象
	        Class<?> clazz = Class.forName(className);
	        
	        // 打印 Class 对象的名称
	        System.out.println("Class loaded: " + clazz.getName());
	        
	        // 创建该类的实例
	        Object instance = clazz.getDeclaredConstructor().newInstance();
	        
	        // 调用类的方法
	        clazz.getMethod(Class_fashion).invoke(instance);  // 调用 MyClass 中的 greet 方法
	    } catch (ReflectiveOperationException e) {
	        e.printStackTrace();
	    }

}



public static void  Demo(String close_add ,String Click ,String System) throws IOException 
{ 
  //---------加入文章------------------------------//
	//word_Demo
	

	



	
	
	
	
	
	

   //-----------------------------------------------//
	// TODO Auto-generated method stub
	 JFrame JF= new JFrame();    
	 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

	 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
	 JF. setLayout(new FlowLayout());
	 JF.setTitle("java");
	 
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
        File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	//     JF.setBounds(100, 100, 400, 400); 
	         
//	 JF.setIconImages(icons); 
//	 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//	 JF.setBounds(300, 200, 200, 200);
//	 JF.setSize(250,130);    
	 JF.setLayout(null);    
		java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    //----------------JPanel-------------------------------//
		
		int width = ((scr_size.width - 300/2) / 2);
		
		int height = ((scr_size.height - 150/2)/2);
		
		
		
    JPanel panel=new JPanel();  
    panel.setBounds(width-20,height,300/2+20,(150/2));    
//    JF.setContentPane(panel);
    panel.setBackground(Color.gray);  
	Color bgColor = new Color(254,249,169);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	panel.setBackground(bgColor);
	Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
	panel.setBorder(BorderFactory.createTitledBorder(genderLine, System));
    
	//---------------------------------------------//
	

	

	

    

    //----獨立確認--------Click-------------------------/
    JButton jButton   = new JButton(Click); 

  jButton.setBounds(width+50, height+40, 50, 20); 
  JF.add(jButton);
 //   jButton.setBackground(new Color(203,0,66));   
    jButton.setFocusable(false);	
    jButton.setHorizontalTextPosition(jButton.CENTER);
    jButton.setVerticalTextPosition(jButton.BOTTOM);
    jButton.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
    jButton.setIconTextGap(-20); //位置 		
    jButton.setForeground(Color.white);
    jButton.setBackground(new Color(203,0,66) );
    jButton.setBorder(BorderFactory.createEtchedBorder());
    JF.add(jButton);
    
    //-------獨立--------close----------------------/
    
    JButton close = new JButton();
		close.setBounds(width+110, height, 40, 18);
		JF.add(close);
		
		//	data.addActionListener((ActionListener) this);
		close.setText(close_add);
		close.setFocusable(false);	
		close.setHorizontalTextPosition(close.CENTER);
		close.setVerticalTextPosition(close.BOTTOM);
		close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
		close.setIconTextGap(-20); //位置 		
		close.setForeground(Color.white);
		close.setBackground(new Color(203,0,66) );
		close.setBorder(BorderFactory.createEtchedBorder());
		JF.add(close);
		
//--------------------------------------------------//			
    
	
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				// System.exit(0);
		//	JF.setExtendedState(JFrame.ICONIFIED);
				JF.dispose();
			}
		});
    
//---------------------------jButton----Click-----------------------------------------------//	     
		 
    
		  jButton.addActionListener(new ActionListener() { 
	            // Anonymous class. 
	  
	            public void actionPerformed(ActionEvent e) 
	            { 
	                // Override Method 
	  
	                // Declaration of String class Objects. 
	                String qual = " "; 
	                //---------music----------------//
	                // If condition to check if jRadioButton2 is selected. 
	                String op="開";
	             	String closure="關";
	             	
	             	
	       
	                // MessageDialog to show information selected radio buttons. 
	            	JF.dispose();
	            } 
	        }); 
		
//-----------------------------------------------------------------------//		
		
		  
		
		//-----------------------------------------------------//
  
  JF.setUndecorated(true);// 窗口去边框
	JF.setBackground(new Color(0,0,0,0));// 设置窗口为透明色 
	  JF.add(panel);
    JF.setVisible(true);            
} 







}