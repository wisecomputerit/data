
public class Lottery_Analysis_System {

}
