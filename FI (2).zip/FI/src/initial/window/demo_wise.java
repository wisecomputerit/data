package initial.window;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class demo_wise {

	
	
	
	static public String fileName ="Loading.wise.🖥️/Loading.txt";
	

	
	
	
	static JPanel contentPane;
	public static void main(int time,String name) throws IOException, InterruptedException {
	
	

		//----------------Declare.wise------------------------------------//
		JFrame jf = new JFrame();
		java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		
		

		contentPane = new JPanel();
		jf.setContentPane(contentPane);//設定內容窗格
		contentPane.setLayout(null); // 沒有填入表單
		jf.setResizable(false);//setResizable 視窗沒有提供
		
		

		/*
		//-------------------------Button.wise--------------------------------------------//
		JButton jb = new JButton();
		jb.setBounds(500, 200, 100, 25);
		jb.setSize(50, 50);//设置按钮大小
		String path = "AIS.jpg";
		//设置图片路径，实践的话根据自己的图片路径另加设置；我这个图片是个笑脸
		ImageIcon icon = new ImageIcon(path);//根据路径创建图标
		Image temp1 = icon.getImage().getScaledInstance(jb.getWidth(),jb.getHeight(), icon.getImage().SCALE_DEFAULT);
		//新建图片，大小调制成和按钮大小一样大
		//getScaledInstance()方法返回的是一个图片，后面的参数在程序下有注解。
		icon = new ImageIcon(temp1);
		//将图片另引用为图标
		jb.setIcon(icon);
		//将图标加载到按钮之上
		contentPane.add(jb);
		
		*/
		
		
		
		//---------------------------------------------------------------------------//
	
		
		//-------------------JFrame.wise-------------------------------------//
		//java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		jf.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕
		jf.setLocation( (scr_size.width - jf.getWidth()) / 2, (scr_size.height - jf.getHeight()) / 2);

		
		

		
		
	//	jf.setDefaultCloseOperation(JFrame. EXIT_ON_CLOSE);// 可以開關
		jf.setUndecorated(true);// 窗口去边框

		jf.setBackground(new Color(0,0,0,0));// 设置窗口为透明色
		// 设置窗口背景
		ImageIcon i = new ImageIcon("螢幕擷取畫面 2024-10-23 191517.jpg");// 指定图片对象
		JLabel imgLabel=new JLabel(i);//将背景图放在标签里。
		jf.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));//
		
		
		int width = ((scr_size.width - jf.getWidth()) / 2)-(i.getIconWidth()/2);
		
		int height =( (scr_size.height - jf.getHeight()) / 2)-(i.getIconHeight()/2);
		
		
		
		
		//------------------BOX------------------------------//
		
		
		
		
		/*
		
		JLabel lblId2 = new JLabel();
		
		ImageIcon box = new ImageIcon("pixel-art-12601_256.gif");// 指定图片对象

		int width_box =  ((scr_size.width - jf.getWidth()) / 2)-(box.getIconWidth()/2)+(box.getIconWidth()/2);
		int height_box =( (scr_size.height - jf.getHeight()) / 2)-(box.getIconHeight()/2)+(box.getIconHeight()/2);
		lblId2.setIcon(box);
		lblId2.setBounds(width_box,height_box, 3000, 300);
        contentPane.add(lblId2);
        
        */
		//----------------文字-------------------------//

		String strMsg1 =name;   
		String strMsg2 = "Loading";  
		String strMsg3 = "Wise Courses Ltd..";  
		String strMsg = "<html><body><h2>" + strMsg1 + "<br>" + strMsg2 + "<br>"+strMsg3+"<body></html>";  
	
		
		JLabel lblId = new JLabel(strMsg);
		lblId.setBounds(width+20, height+i.getIconHeight()/2, 800, 80);
		//--------------文字---------------------------//
		contentPane.add(lblId);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		imgLabel.setBounds(width, height, i.getIconWidth(), i.getIconHeight());//7
		Container cp = jf.getContentPane();
		cp.setLayout(new BorderLayout());
		((JPanel) cp).setOpaque(false);
		jf.show();
		

		//---------------------icon.wise-------.-----------------------------------------//
		
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
         File imageFile = new File(imagePath);
	      icons.add(ImageIO.read(imageFile));
	    
	      jf.setIconImages(icons); 
	      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 // 寬 長
		//-------------------------------------//
		
	      
	
	      Thread.sleep(time);
	

		// jf.setUndecorated(true);
		jf.setVisible(true);
		
		jf.dispose();
	}
	
	
	public static String  getSwitch_options_Loading( ) // 獲取開關
	{
		//Loading.wise.🖥️
	
		  String Name = null;
	        FileReader fr = null;
	        try {
	            fr = new FileReader(fileName);
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
	        BufferedReader br = new BufferedReader(fr);
	        String tmp = null;

	        try {
	            while (((tmp = br.readLine()) != null)) {
	   
	            	Name=tmp;
	            	
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                br.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
			return Name;
	
	
	}
	
	
	
	

}
