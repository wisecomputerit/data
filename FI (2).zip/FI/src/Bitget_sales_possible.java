import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Bitget_sales_possible {
	

	//---------JFrame-------------------// 
	public static JFrame f;  //制定視窗
    static  Color getColor = AIS.getColor_JFrame; //制定視窗 顏色  
      public static  Color getColor_JButtonTXT = new Color(254,186,41); //背景顏色JButtonTXT  黃色 

    //-----------------------------------------------//
	public static  int w = 680+200; //制定大小
	public static  int h = 680;
	
	public static  int win_JFrameWidth = 100,  win_JFramegetHeight = 30;// 位置
	

	//-----------Translate----------------// 
    static   String[] TranslateSystem; // 制定翻譯視窗系統
    static String[] Bitget_sales_possible; // 制定翻譯功能系統
    //-----------------按鈕URL --------------------------//
    
    static   String UELname="https://www.bitget.com/zh-TW/";
 
	//-----------JTextField----輸入格------------// 
     static  JTextField[] JFtxt   =new JTextField [5];
    
    
    
    
    //Bitget sales possible
    
    
    
    
    
    
    
    
    
    
    
    public static JPanel menu(JFrame f) throws IOException {
   
    	TranslateSystem =nat.read_System( );
	     
		 JPanel menu=new JPanel(); 
		 menu.setBounds(w/3-20,h-h/7,w,h/11); //位置  // 大小  
		 menu.setBackground(new Color(240,240,240) );
		 menu.setLayout(null); // 使用絕對定位
		//	f.setContentPane(menu);

			int menu_H  = h-h/7;
			int menu_W=w/3-20 ;
			
			
		

        //--------------JPanel----menu.wsie----------------------//
	     
	
			
			
	       
	//------------------JButton--menu--------------Start------------------//   
		     JButton b1=new JButton(Bitget_sales_possible[2]);     //  OK
		 

		       
		     b1.setBounds(270,10,100,25);  
		     b1.setForeground(getColor);
		     b1.setBackground(Color.white);  
//		     b1.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//		     b2.setBorderPainted(false); // 移除邊框
		     b1.setFocusPainted(false); // 移除焦點框
		     menu.add(b1);

		     	b1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
				           
					
					
						try {
							AIS.main_start();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
						String TxtId = JFtxt[0].getText();
						double x = Double.parseDouble(TxtId);
						 System.out.println("錢包 多少U");
						 
							String TxtId1 = JFtxt[1].getText();
							double y  = Double.parseDouble(TxtId1);

			
						 
								String TxtId2 = JFtxt[2].getText();
								double Opening_price = Double.parseDouble(TxtId2);

			
						 
									String TxtId3 = JFtxt[3].getText();
									double target_price = Double.parseDouble(TxtId3);

						
						 
										String TxtId4 = JFtxt[4].getText();
										double c  = Double.parseDouble(TxtId4);

					//---------------------------------------------------------------//			
							 
					double Open_wallet = x / y;
					
					String[] Data = new String[(int) y];
					String data = "";
					for (int i = 0; i < y; i++) {

						// System.out.println("第"+(i+1)+"倉位"+Open_wallet+"usdt");
						Data[i] = Bitget_sales_possible[9] + (i + 1) + Bitget_sales_possible[10] + Open_wallet +" "+ Bitget_sales_possible[11]+"\n";
						data = data + Data[i];

					}
					
				
						 
					JOptionPane.showMessageDialog(null,"" + data + Bitget_sales_possible[12] + x +  Bitget_sales_possible[11] + " | "+Bitget_sales_possible[13] + Opening_price + Bitget_sales_possible[11] + " | "
									+Bitget_sales_possible[14] + target_price +Bitget_sales_possible[11]+" | "+ c + Bitget_sales_possible[15] + "\n ",
									TranslateSystem[3], JOptionPane.INFORMATION_MESSAGE); 
						 
						 
					
					
					
					double spread = target_price - Opening_price;
					
					int mType = JOptionPane.INFORMATION_MESSAGE;
					String in1 = JOptionPane.showInputDialog(null, Bitget_sales_possible[16], Bitget_sales_possible[17], mType);
					
					
					double N = Double.parseDouble(in1);// 預計目標價格

					double U = Open_wallet / N; // 本來就應該放入多少貨幣
					System.out.println("應該放入該貨幣" + U + "數量即可"+"總共多少U"+(U*Opening_price) + "我該保留多少U才不會爆倉" + (x / 2));
					System.out.println("統一USDT 初始保證金 " + ((U * Opening_price) / c) + "USDT");
					double OUT = ((U * Opening_price) / c);

					System.out.println("保證金維持率");
					double FF = 1 - (1 / y);

					System.out.println("維持率 " + FF + "");
					double input = U * Opening_price * FF;
					System.out.println("維持保證金 " + input + "USDT");

					System.out.println("強平價格 " + (Opening_price - (OUT - input)) + "USDT");

					String[] Data_data = { Bitget_sales_possible[18] + U + Bitget_sales_possible[19] +"\n"+Bitget_sales_possible[20]+(U*Opening_price)+Bitget_sales_possible[11]+"\n",
					       Bitget_sales_possible[21] + (x / 2) + Bitget_sales_possible[11] + "\n",
							Bitget_sales_possible[22] + ((U * Opening_price) / c) +Bitget_sales_possible[11] + "\n", 
							Bitget_sales_possible[23]  + FF + "" + "\n",
							Bitget_sales_possible[24] + input + "USDT" + "\n",
							Bitget_sales_possible[25]  + (Opening_price - (OUT - input)/2) + Bitget_sales_possible[11] + "\n"

					};
					
				
					
					      //	System.out.println(N);
							JOptionPane.showMessageDialog(null,	Data_data[0] + Data_data[1] + Data_data[2] + Data_data[3] + Data_data[4]+Data_data[5], TranslateSystem[4],JOptionPane.INFORMATION_MESSAGE);		
							
					}
				});
		     
	 //------------------JButton----menu------------------------------//   	     
		 
	     JButton b2=new JButton(Bitget_sales_possible[1]);   //   menu 
	   //  b2.setBounds(100,100,80,30);    
	     b2.setForeground(getColor);
	     b2.setBackground(Color.white);   
	     b2.setBounds(400,10,100,25);    
	//     b2.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//	     b2.setBorderPainted(false); // 移除邊框
	     b2.setFocusPainted(false); // 移除焦點框
	     menu.add(b2); 

	         
	         //   menu 

	         b2.addActionListener(new ActionListener() { 
					public void actionPerformed(ActionEvent e) {

						
						try {
							AIS.main_start();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
						
						
						f.dispose();
				
						
						
	
						main_min main_min=new main_min();
						
						
						try {
			
							main_min.man();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
					
					
					
				
			
					
				
				
					}
				});
				

		return menu;
    }
    
	public static JPanel Panel() throws IOException {
		
	       
			 JPanel panel=new JPanel(); 
		     panel.setBounds(0,0,w/3-20,h); //位置  // 大小  
		   //  panel.setBackground(Color.yellow);
		     panel.setBackground(getColor );

		       
		//------------------JPanel.wsie----------------------------------//   
		
		     
		      String m=  "<html><h2 style='color:white;'>"
		      		+ TranslateSystem[3] //Artificial intelligence
		      		+ "<i>!"
		      		+ "</h2><br><br><br><br><h2 style='color:white'> "
		      		+  Bitget_sales_possible[0]//ANN
		      		+ "</h2></html>";
		     
		     JLabel   music_wise= new JLabel(m); 
		     music_wise.setForeground(new Color(254,186,41)); // 設置文字顏色為紅色
		     panel.add(music_wise); 
		       


	 //------------------------------------------------------//
		     
		     
		     JButton b0=new JButton(Bitget_sales_possible[3]);     //Algorithm information

		       
		     b0.setBounds(150,10,100,25);  
		     b0.setForeground(getColor);
		     b0.setBackground(Color.white);  
//		     b1.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//		     b2.setBorderPainted(false); // 移除邊框
		     b0.setFocusPainted(false); // 移除焦點框
		     panel.add(b0);
		     
		     //------  //Algorithm information-----------//
	         
	         b0.addActionListener(new ActionListener() { //  //Algorithm information
				public void actionPerformed(ActionEvent e) {

					try {
						AIS.main_start();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
							| InterruptedException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					  
					AIS.chome(UELname);
			
				}
			});
	         
	         //------------------------------------------------------//

		
	       
         return panel;
	}
	public static JPanel Frame_Panel() throws IOException {

	     
				//---------------Frame_Panel----------------------//

		
				 JPanel Frame_Panel=new JPanel();  
				 Frame_Panel.setBounds(w/3-20,0,w-w/3+5,h-h/11); //位置  // 大小   // 撿到側邊欄位W  跟  menu底下欄位H
			   //  panel.setBackground(Color.yellow);
				 Frame_Panel.setBackground(Color.white );
			          Frame_Panel.setLayout(null); 
		       
		       
			     
					//---------------Frame_Panel.wise----------------------//
		       
				 String Frame_Panel_name=  "<html><h2 style='color:rgb(0,183,100);'>"
				 		+ TranslateSystem[3] // AIS 標題系統
				 				+"<br>"+"<br>"
				 		+  Bitget_sales_possible[0] // 系統 名稱
				 		+ "</h2>"
				 		+ "<h2>"
				 		+ TranslateSystem[6]// 左邊標語
				 		+ "</h2>"
				 		+ "</html>";
			     JLabel   music_wise2= new JLabel( Frame_Panel_name); 
			     music_wise2.setForeground(new Color(254,186,41)); // 設置文字顏色
			     music_wise2.setBounds(10,20,500,200);  
			       
			     Frame_Panel.add(music_wise2); 
			//-------------------------------------------------------------//
			     /*
			
			     */
			     
			      int setColumns_wise=20;
			     
				     JPanel System=new JPanel();  
				     System.setBounds(10,20+200,500,500);  
				     System.setBackground(Color.white );//-----------------------System-------JPanel-------------//
				     System.setLayout(null); 
				     Frame_Panel.add(System); 
				  
			
					//-------------wallet-------------------------------//    
				     JLabel   wallet= new JLabel( Bitget_sales_possible[4]); 
				     wallet.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     wallet.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     wallet.setBounds((w/3-20)/2,-70,500,200);  
				     System.add(wallet); 
			    
				     

				     
				          JFtxt[0] = new JTextField();
				        JFtxt[0].setColumns(setColumns_wise);
				        JFtxt[0].setBounds((w/3-20)/2,50,200,20);
				        System.add(JFtxt[0]);
				     
				     
						//-------------several_portions-------------------------------//   
				     JLabel   several_portions= new JLabel( Bitget_sales_possible[5]); 
				     several_portions.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     several_portions.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     several_portions.setBounds((w/3-20)/2,0-10,500,200);  
				     System.add(several_portions); 
			     
				     
			          JFtxt[1] = new JTextField();
			          JFtxt[1].setColumns(setColumns_wise);
				      JFtxt[1].setBounds((w/3-20)/2,110,200,20);
			        System.add(JFtxt[1]);
			     
			     
			     
					//-------------several_portions-------------------------------//   
				     JLabel    invest= new JLabel( Bitget_sales_possible[6]); 
				     invest.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     invest.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     invest.setBounds((w/3-20)/2,50,500,200);  
				     System.add(invest); 
			     //------------------------------------------------------//
				     
			          JFtxt[2] = new JTextField();
			          JFtxt[2].setColumns(setColumns_wise);
				      JFtxt[2].setBounds((w/3-20)/2,170,200,20);
			        System.add(JFtxt[2]);
			     
				  //--------------------------------------------------------// 
			         JLabel    price_target= new JLabel( Bitget_sales_possible[7]); 
			         price_target.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
			         price_target.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
			         price_target.setBounds((w/3-20)/2,110,500,200);  
				     System.add(price_target); 
				     
				     //----------------------------------------------//
			         JFtxt[3] = new JTextField();
			          JFtxt[3].setColumns(setColumns_wise);
				      JFtxt[3].setBounds((w/3-20)/2,230,200,20);
			        System.add(JFtxt[3]);
				     //------------------------------------------------------//
			        
			        JLabel    lever= new JLabel( Bitget_sales_possible[8]); 
			        lever.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
			        lever.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
			        lever.setBounds((w/3-20)/2,170,500,200);  
				     System.add(lever); 
				     
				     //----------------------------------------------//
			         JFtxt[4] = new JTextField();
			          JFtxt[4].setColumns(setColumns_wise);
				      JFtxt[4].setBounds((w/3-20)/2,290,120,20);
			        System.add(JFtxt[4]);
		       
	 return Frame_Panel;
	}
	
	
    
    
	public static void main() throws IOException {

			  ResizeImageExample();
	
	}

	private static void ResizeImageExample() throws IOException {
		
		//---------------TranslateSystem---------------------------//
	     TranslateSystem =nat.read_System( );
		   
	     Bitget_sales_possible=nat.get_Bitget_sales_possible();
	     
	     
	     
		   //---------------------------------//
	
		 //---------------JFrame----------------------//
	    	 JFrame f= new JFrame( TranslateSystem[3]);  //標題
	        	String path = "AIS.jpg";
		     Image icon = Toolkit.getDefaultToolkit().getImage(path);
		       f.setIconImage(icon);
	//	       f.getContentPane().setBackground(Color.white);

		   	//------------------Frame_Panel----------------------------------//    
		       JPanel Frame_Panel =  Frame_Panel();
	
		//------------------JPanel----------------------------------//       
		   

		       JPanel panel =  Panel();
		       

		       //-----------------menu- ---------------------//	       
		       
		       JPanel menu =  menu(f);
		       
	     
	     //-----------------------------------------//
	     //-------------結尾-----------------------//     
         f.add(panel); 
         f.add(menu); 
         f.add( Frame_Panel);
	     //-----------JFrame------------------------//
         //----------------------------------//
	
	      f.setBounds(win_JFrameWidth,win_JFramegetHeight,w,h);    
          f.setLayout(null);    
          // 禁止調整視窗大小
          f.setResizable(false);
          f.setVisible(true);   
 
          
   
	}

	
	
	

}
