import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import message.box.Message;





public class main_min {
	
	public static int SUM=0; 

	
	
	public static String Str ;
	
	
	static   nat n = new nat();   

	static String Keyname = "data.wise.🗄️";
	
	
	public static void man( ) throws UnsupportedAudioFileException, IOException, LineUnavailableException, InterruptedException {
	
	
		String [] KEY_nat =n.read_KEY();
		
		  String[] Result =nat.read_result();

		

		   String[] TranslateSystem =nat.read_System( );
		   
		   
		   String[] Translatemain =nat.read_main( );
			
		   
	
		
		JFrame jFrame = new JFrame();
		jFrame.setSize(300, 200);
		jFrame.setLayout(null);

		JTextField textField = new JTextField();
		textField.setBounds(50, 50, 200, 30);
		
		jFrame.add(textField);
		


		
		
			int mType = JOptionPane.INFORMATION_MESSAGE;

	
	//		String in2 = (String) JOptionPane.showInputDialog(jFrame, Result[0]+"\n"+Result[1] +"\n"+ Result[2]+"\n"+ TranslateSystem[1], TranslateSystem[2], mType, null, Translatemain, "");
		
			
			
			
			
			
			
			
			 String Frame_Panel_name=  "<html><h4 style='color:'>"
				 		+ Result[0] // AIS 標題系統
				 				+"<br>"
				 				+ Result[1] // AIS 標題系統
				 						+"<br>"
						 				+ Result[2] // AIS 標題系統
						 						+"<br>"
								 			
				 		+ "</h4>"
				 		+ "</html>";
			 
			 
		
		
                            
				String	in2 =  MenuBox.setMenuBox(Translatemain, Result[4], Result[5], Result[6],Frame_Panel_name,
						Result[7], AIS.ColorsetBackground_AIS,"main_min","man");
		
			
				 
	//		String in2  = MenuBox.getMenuBox();
	//		System.out.print(" IntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntIntInt  = " +in2+"\n");
			
			
			
			   String[] Translate_main_menu =nat.read_main( );

	
			if (in2 == null) {
				
				
				AIS.main_option();
				
			//	JOptionPane.showMessageDialog(jFrame, TranslateSystem[0]);
				
				new Message (Result[4],Result[5]);
	          //	System.exit(0);
	          
				
			} 
			

			if (in2.equals(Translate_main_menu[0])) {
				

				//JFJF.dispose();
				AIS.main_start();

				Bitget_sales_possible ann=  new Bitget_sales_possible();
				
				
				ann.main();
				
				
			
	}
			
			
			if (in2.equals(Translate_main_menu[1])) {
				
				
		
				AIS.main_start();

			
		
				String key="1";
				if(key==DaTa())
				{
			//		KNN_wise KNN=  new KNN_wise();
			//		KNN.main();
			
					
					Bitget_Lending_System ann=  new Bitget_Lending_System();
					
					
					ann.main();
					
					//JOptionPane.showMessageDialog(null, "OK");
				}
				else
				{
					
					JOptionPane.showMessageDialog(null, KEY_nat[10]);
				}
				

	}
		
			
			if (in2.equals(Translate_main_menu[2])) {
				
				
				AIS.main_start();

		

				String key="1";
				if(key==DaTa())
				{
			//		SVM svm=  new SVM();
					
					bitunix_system_only   Frame_Panel= new bitunix_system_only();
					Frame_Panel.main();
				}
				else
				{
					
					JOptionPane.showMessageDialog(null, KEY_nat[10]);
				}
				
	}
			
			if (in2.equals(Translate_main_menu[3])) {
				
				
				AIS.main_start();

		
				
				String key="1";
				if(key==DaTa())
				{
			//		Decisiontree tree=  new Decisiontree();
					
					Query_currency_only Frame_Panel =new Query_currency_only();
					
					Frame_Panel.main();
				}
				else
				{
	            	   
					JOptionPane.showMessageDialog(null,KEY_nat[10]);
				}
				

	}
		
			
			
			
			
			
			
			
			
			
			
	}



	public static String DaTa() throws IOException  {
	
  BufferedReader Reader = null;

   String Str = "";
   
   int NA ;
 
  try {
		Reader = new BufferedReader(new InputStreamReader(new FileInputStream(Keyname+"\\" +"local" + ".txt"), "UTF-8"));
		
		      while ((Str = Reader.readLine()) != null) {
		    	  NA=    Integer.parseInt(Str);  
		    	   System.out.println("NA ="+NA);
		    	  if(NA==0) {
		    		  
		    		  
		    		  SUM=0;
		    	  }  if(NA==1) {
		    		  
		    		  
		    		  SUM=1;
		    	  }
		     }
		      
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
	   	  Str="0";
		e.printStackTrace();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} // 指定讀取文件的編碼格式，以免出現中文亂碼
 
    

    
    String route;
    route = Keyname;
    String name = "local.txt";
	    File dir = new File(route);
    File filename = new File(route,name);
    System.out.println("檔案名稱 : "+name);
    System.out.println("檔案是否存在 : "+filename.exists());  
    
    
    if(filename.exists()==false) {
 
  	  Str="0";
  	  
  	//  JOptionPane.showMessageDialog(null, "未開通付費");
    }
    if(filename.exists()==true) {
  
  	  if(SUM==1)
  	  {
  		  Str="1";
  	  }
  	  if(SUM==0)
  	  {
  		  Str="0";
  	  }

    }
    
    System.out.println("Str = :"+Str);  
	return Str;
    
         }
	
	
}
