
public class translateclass {
	
	public static	String Classname;
	public static String Class_fashion;
	
	
	public static   void inputclass_fashion (String Class ,String e ) {
		
		Classname=Class;
		 Class_fashion =e;
		
	}
	
	
	
 
	public static void Run_class_fashion( ) {
		  try {
			  
			  
			  
			  
			  
		        // 这里替换为你自己的类名（没有包名）
		        String className = Classname;  // 不需要加包名
		        
		        // 使用 Class.forName() 获取 Class 对象
		        Class<?> clazz = Class.forName(className);
		        
		        // 打印 Class 对象的名称
		        System.out.println("Class loaded: " + clazz.getName());
		        
		        // 创建该类的实例
		        Object instance = clazz.getDeclaredConstructor().newInstance();
		        
		        // 调用类的方法
		        clazz.getMethod(Class_fashion).invoke(instance);  // 调用 MyClass 中的 greet 方法
		    } catch (ReflectiveOperationException e) {
		        e.printStackTrace();
		    }

	}

}
