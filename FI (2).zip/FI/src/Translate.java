import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Translate {
	

	static   nat n = new nat();
      // JF.dispose(); 關閉先前視窗 立即開啟新翻譯好的視窗
	
	static JFrame JF;
	
	public static void man( ) throws UnsupportedAudioFileException, IOException, LineUnavailableException, InterruptedException {
	

		
		
	    String[] nation=nat.read_nation();
	    String[] TranslateSystem =nat.read_System();
		
		  String[] Result =nat.read_result();
	    
	    
		JFrame jFrame = new JFrame();
		jFrame.setSize(300, 200);
		jFrame.setLayout(null);

		JTextField textField = new JTextField();
		textField.setBounds(50, 50, 200, 30);
		jFrame.add(textField);


		  
			//int mType = JOptionPane.INFORMATION_MESSAGE;

		
	//	String in2 = (String) JOptionPane.showInputDialog(jFrame, TranslateSystem[1], TranslateSystem[2], mType, null, nation,JOptionPane.INFORMATION_MESSAGE);
		
			
		String	in2 = MenuBoxJComboBox.setMenuBox(nation, Result[4], Result[5], Result[6],TranslateSystem[8],TranslateSystem[2], AIS.ColorsetBackground_AIS);
		System.out.print(" Int  = " +in2+"\n");
		/*
			for(int i=0;i<nation.length;i++) //全部指令 //預先處理
			{
				if (in2 == nation[i]) {
					 AIS.main_start(); //音效
						
					 JF.dispose();   // 關閉當前視窗
					
				}
			 
			}
		
			*/
	
			
		//	nat.language(in2);  // 存檔後 再開啟 選後處理
			if (in2 == null) {   // 關閉指令
				 AIS.main_start();
				 JF.dispose();  
				 new AIS();
			}
			
	
			
			
			if (  in2.equals(nation[0])) {
			n.Afrikaans();
			 AIS.main_start(); //音效
			 JF.dispose();   // 關閉當前視窗
			 
			
	}
			if (in2.equals(nation[1])) {
          n .Albanian();
          AIS.main_start(); //音效
     	 JF.dispose();   // 關閉當前視窗	
		
	}
			if (in2.equals(nation[2])) {
			n.Amharic();
			   AIS.main_start(); //音效
		     	 JF.dispose();   // 關閉當前視窗	
	}
			if (in2.equals(nation[3])) {
			n.Arabic();
			   AIS.main_start(); //音效
		     	 JF.dispose();   // 關閉當前視窗	
	}
			if (in2.equals(nation[4])) {
			n.Armenian();
			   AIS.main_start(); //音效
		     	 JF.dispose();   // 關閉當前視窗	
	}
			if (in2.equals(nation[5])) {
				n.Assamese();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
			if (in2.equals(nation[6])) {
	          n .Azerbaijani();
			   AIS.main_start(); //音效
		     	 JF.dispose();   // 關閉當前視窗	
		}
			if (in2.equals(nation[7])) {
				n.Belarusian();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
			if (in2.equals(nation[8])) {
				n.Bemba();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
			if (in2.equals(nation[9])) {
				n.Bengali();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
			if (in2.equals(nation[10])) {
					n.Bosnian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				//----------------------10-----------------------------------------------------//
				
				
			if (in2.equals(nation[11])) {
					n.Bulgarian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
			if (in2.equals(nation[12])) {
					n.Burmese();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[13])) {
					n.Catalan();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[14])) {
					n.Chichewa();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[15])) {
					n.Chinese_Simplified();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[16])) {
					n.Chinese_Traditional();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[17])) {
					n.Creole();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[18])) {
					n.Croatian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[19])) {
					n.Czech();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			if (in2.equals(nation[20])) { 
					n.Danish();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
	
				
				//----------------------20-----------------------------------------------------//	
				
	         if (in2.equals(nation[21])) {
					n.Dari();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
	     	if (in2.equals(nation[22])) {
					n.Dutch();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
				
	    	if (in2.equals(nation[23])) {
					n.Dzongkha();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[24])) {
					n.English();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[25])) {
					n.Estonian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[26])) {
					n.Fijian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[27])) {
					n.Finnish();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[28])) {
					n.French();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
				
	    	if (in2.equals(nation[29])) {
					n.Georgian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
			
			
				if (in2 == nation[30]) {
					n.German();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
				//----------------------30-----------------------------------------------------//	
				
				if (in2.equals(nation[31])) {
					n.Greek();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
			
				
				if (in2.equals(nation[32])) {
				n.Guarani();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
				if (in2.equals(nation[33])) {
	          n .Hausa();
			   AIS.main_start(); //音效
		     	 JF.dispose();   // 關閉當前視窗	
		}
				if (in2.equals(nation[34])) {
				n.Hebrew();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
				if (in2.equals(nation[35])) {
				n.Hindi();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
				if (in2.equals(nation[36])) {
				n.Hungarian();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
		}
				if (in2.equals(nation[37])) {
					n.Indonesian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[38])) {
		          n .Irish();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[39])) {
					n.Italian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[40])) {
					n.Japan();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
		
					//----------------------40-----------------------------------------------------//				
					
				if (in2.equals(nation[41])) {
						n.Kannada();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				
					
				if (in2.equals(nation[42])) {
					n.Khmer();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[43])) {
		          n .Kikongo();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[44])) {
					n.Kinyarwanda();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[45])) {
					n.Korean();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[46])) {
					n.Lao();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[47])) {
						n.Latin();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[48])) {
			          n .Latvian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[49])) {
						n.Lingala();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[50])) {
						n.Lithuanian();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
						//----------------------50-----------------------------------------------------//						
					
					
					
					
					
				if (in2.equals(nation[51])) {
						n.Luganda();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				
				if (in2.equals(nation[52])) {
					n.Macedonian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[53])) {
		          n .Malagasy();
				   AIS.main_start(); //音效
			     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[54])) {
					n.Malay();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[55])) {
					n.Malayalam();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[56])) {
					n.Marathi();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
			}
				if (in2.equals(nation[57])) {
						n.Marshallese();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[58])) {
			          n .Mongolian();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[59])) {
						n.Nepali();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[60])) {
						n.Norwegian();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
						//----------------------60-----------------------------------------------------//		
				if (in2.equals(nation[61])) {
							n.Pashto();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
					
						
				if (in2.equals(nation[62])) {
						n.Persian();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[63])) {
			          n.Polish();
					   AIS.main_start(); //音效
				     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[64])) {
						n.Portuguese();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[65])) {
						n.Punjabi();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[66])) {
						n.Romanian();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
				}
				if (in2.equals(nation[67])) {
							n.Russian();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[68])) {
				          n .Samoan();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[69])) {
							n.Sanskrit();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[70])) {
							n.Serbian();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}	
							//----------------------70-----------------------------------------------------//			
				if (in2.equals(nation[71])) {
								n.Shona();
								   AIS.main_start(); //音效
							     	 JF.dispose();   // 關閉當前視窗	
						}
						
				if (in2.equals(nation[72])) {
							n.Sinhala();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[73])) {
				          n .Slovak();
						   AIS.main_start(); //音效
					     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[74])) {
							n.Slovenian();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[75])) {
							n.Somali();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[76])) {
							n.Spanish();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
					}
				if (in2.equals(nation[77])) {
								n.Swahili();
								   AIS.main_start(); //音效
							     	 JF.dispose();   // 關閉當前視窗	
						}
				if (in2.equals(nation[78])) {
					          n .Swedish();
							   AIS.main_start(); //音效
						     	 JF.dispose();   // 關閉當前視窗	
						}
				if (in2.equals(nation[79])) {
								n.Tamil();
								   AIS.main_start(); //音效
							     	 JF.dispose();   // 關閉當前視窗	
						}
				if (in2.equals(nation[80])) {
								n.Tetum();
								   AIS.main_start(); //音效
							     	 JF.dispose();   // 關閉當前視窗	
						}		
								
								
								//----------------------80-----------------------------------------------------//			
								
				if (in2.equals(nation[81])) {
									n.Thai();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
							}	
					
				if (in2.equals(nation[82])) {
										n.Tongan();
										   AIS.main_start(); //音效
									     	 JF.dispose();   // 關閉當前視窗	
								}
								
									
				if (in2.equals(nation[83])) {
									n.Turkish();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
							}
				if (in2.equals(nation[84])) {
						          n .Turkmen();
								   AIS.main_start(); //音效
							     	 JF.dispose();   // 關閉當前視窗	
							}
				if (in2.equals(nation[85])) {
									n.Ukrainian();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
							}
				if (in2.equals(nation[86])) {
									n.Urdu();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
							}
				if (in2.equals(nation[87])) {
									n.Uzbek();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
							}
				if (in2.equals(nation[88])) {
										n.Vietnamese();
										   AIS.main_start(); //音效
									     	 JF.dispose();   // 關閉當前視窗	
								}
				if (in2.equals(nation[89])) {
							          n .Xhosa();
									   AIS.main_start(); //音效
								     	 JF.dispose();   // 關閉當前視窗	
								}
			        	if (in2.equals(nation[90])) {
										n.Yoruba();
										   AIS.main_start(); //音效
									     	 JF.dispose();   // 關閉當前視窗	
								}
										
				//----------------------90-----------------------------------------------------//										
										
			        	if (in2.equals(nation[91])) {
										n.Zulu();
										   AIS.main_start(); //音效
									     	 JF.dispose();   // 關閉當前視窗	
								}	
			        	
			        	if (in2.equals(nation[92])) {
											n.kazakh();
											   AIS.main_start(); //音效
										     	 JF.dispose();   // 關閉當前視窗	
			        	}
			        	
			        	
				
			
			
			
	}

    public static void Delete_window(JFrame JFF) throws IOException
    {
    //OK
    	JF=JFF;

    	
    }


           public static void File_changed(String name) throws IOException
           { // Can be changed
        	   
        

   		  // String data = "Hello, world!";

       	    
       	    File KNN = new File("translate.wise.💬");   
       	    KNN.mkdir(); 
       	    
       	    
            try {
              // create a FileWriter object with the file name
              FileWriter writer = new FileWriter("translate.wise.💬/translate.txt");

              // write the string to the file
              writer.write(name);

              // close the writer
              writer.close();

              System.out.println("Successfully wrote text to file.");

          } catch (IOException e) {
              System.out.println("An error occurred.");
              e.printStackTrace();
          }
            
           }



}
