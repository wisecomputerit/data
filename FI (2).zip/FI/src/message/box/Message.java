package message.box;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;

//---拖住按鈕移動//
public class Message extends JFrame implements MouseListener, MouseMotionListener {
           

	 JButton button2= new JButton();
		JButton button1= new JButton();
	  JPanel panel=new JPanel();  

int x0, y0;
int x3,y3;//记录鼠标拖动之前原来的鼠标位置的东东
public Message(String OK,String close) throws IOException {

	button1.setText(OK);
	button2.setText(close);
	 JFrame JF= this;  		
		

	    //-----------------------------------------------//
		// TODO Auto-generated method stub
		
	 
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
       File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	     
	     JF.setIconImages(icons); 
		 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

		 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
		 JF. setLayout(new FlowLayout());
		 JF.setTitle("java");
		 
		
		//     JF.setBounds(100, 100, 400, 400); 
		         
//		 JF.setIconImages(icons); 
//		 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//		 JF.setBounds(300, 200, 200, 200);
//		 JF.setSize(250,130);    
		 JF.setLayout(null);    
			java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	     //----------------JPanel-------------------------------//
			
			int width = ((scr_size.width - 300/2) / 2);
			
			int height = ((scr_size.height - 150/2)/2);
			
			
			
	   
	     panel.setBounds(width-20,height,300/2+20,(150/2));    
	 //    JF.setContentPane(panel);
	     panel.setBackground(Color.gray);  
	 	Color bgColor = new Color(243,243,243);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	 	panel.setBackground(bgColor);
		Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
		panel.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));
	     
		//---------------------------------------------//
		

		

		

	     

	     //----獨立確認--------Click-------------------------/
	  //   JButton jButton   = new JButton("Click"); 

		button1.setBounds(width+50, height+40, 50, 20); 
	     JF.add(button1);
	  //   jButton.setBackground(new Color(203,0,66));   
	     button1.setFocusable(false);	
	     button1.setHorizontalTextPosition(button1.CENTER);
	     button1.setVerticalTextPosition(button1.BOTTOM);
	     button1.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	     button1.setIconTextGap(-20); //位置 		
	     button1.setForeground(Color.white);
	     button1.setBackground(new Color(203,0,66) );
	     button1.setBorder(BorderFactory.createEtchedBorder());
	     JF.add(button1);
	     
	     //-------獨立--------close----------------------/
	     
	  //   JButton button2 = new JButton();
	     button2.setBounds(width+110, height, 40, 18);
			JF.add(button2);
			
			//	data.addActionListener((ActionListener) this);
	//		button2.setText("close");
			button2.setFocusable(false);	
			button2.setHorizontalTextPosition(button2.CENTER);
			button2.setVerticalTextPosition(button2.BOTTOM);
			button2.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
			button2.setIconTextGap(-20); //位置 		
			button2.setForeground(Color.white);
			button2.setBackground(new Color(203,0,66) );
			button2.setBorder(BorderFactory.createEtchedBorder());
			JF.add(button2);
			
	//--------------------------------------------------//			
	     
	 	
			button2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
					JF.dispose();
				}
			});
	     
	//---------------------------jButton----Click-----------------------------------------------//	     
			 
	     
			button1.addActionListener(new ActionListener() { 
		            // Anonymous class. 
		  
		            public void actionPerformed(ActionEvent e) 
		            { 
		                // Override Method 
		  
		                // Declaration of String class Objects. 
		                String qual = " "; 
		                //---------music----------------//
		                // If condition to check if jRadioButton2 is selected. 
		                String op="開";
		             	String closure="關";
		             	
		             	
		       
		                // MessageDialog to show information selected radio buttons. 
		            	JF.dispose();
		            } 
		        }); 
			
	//-----------------------------------------------------------------------//		
			
			  
			
			//-----------------------------------------------------//
	   
	


/*


button1.setBackground(Color.gray);  
Color bgColor = new Color(70,165,165);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
button1.setBackground(bgColor);
Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
button1.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));

*/


			panel.addMouseListener(this);
			panel.addMouseMotionListener(this);//添加监视器

			
			
			
setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

setUndecorated(true);// 窗口去边框
setBackground(new Color(0,0,0,0));// 设置窗口为透明色   

add(panel);
setVisible(true);
setResizable(false);//设置大小不可调节




}








public void mouseEntered(MouseEvent e) {}

public void mouseReleased(MouseEvent e) {}







public void mousePressed(MouseEvent e){//记录鼠标拖动之前原来的鼠标位置的东东
x3 = e.getX();
y3 = e.getY();
}




public void mouseClicked(MouseEvent e) {}





public void mouseExited (MouseEvent e) {}

         public void mouseDragged(MouseEvent e) {
       	  x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int x1=button1.getBounds().x;// 获取按钮坐标
       	  int y1 = button1.getBounds().y;
       	  button1.setLocation(x0 + x1 - x3, y0 + y1 - y3);

       	  
       	  
       	  int X1=button2.getBounds().x;// 获取按钮坐标
       	  int Y1 = button2.getBounds().y;
       	  button2.setLocation(x0 + X1 - x3, y0 + Y1 - y3);
       	  
          	  
         	  x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int XX1=panel.getBounds().x;// 获取按钮坐标
       	  int YY1 = panel.getBounds().y;
       	  panel.setLocation(x0 + XX1 - x3, y0 + YY1 - y3);

}

         public void mouseMoved(MouseEvent e) {}
         
public static void main(String[] args) throws IOException {
	Message test = new Message("","");// GA

}




public static void  Demo(String close_add ,String Click ,String System) throws IOException 
{ 
  //---------加入文章------------------------------//
	//word_Demo
	

	



	
	
	
	
	
	

   //-----------------------------------------------//
	// TODO Auto-generated method stub
	 JFrame JF= new JFrame();    
	 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

	 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
	 JF. setLayout(new FlowLayout());
	 JF.setTitle("java");
	 
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
        File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	//     JF.setBounds(100, 100, 400, 400); 
	         
//	 JF.setIconImages(icons); 
//	 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//	 JF.setBounds(300, 200, 200, 200);
//	 JF.setSize(250,130);    
	 JF.setLayout(null);    
		java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    //----------------JPanel-------------------------------//
		
		int width = ((scr_size.width - 300/2) / 2);
		
		int height = ((scr_size.height - 150/2)/2);
		
		
		
    JPanel panel=new JPanel();  
    panel.setBounds(width-20,height,300/2+20,(150/2));    
//    JF.setContentPane(panel);
    panel.setBackground(Color.gray);  
	Color bgColor = new Color(254,249,169);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	panel.setBackground(bgColor);
	Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
	panel.setBorder(BorderFactory.createTitledBorder(genderLine, System));
    
	//---------------------------------------------//
	

	

	

    

    //----獨立確認--------Click-------------------------/
    JButton jButton   = new JButton(Click); 

  jButton.setBounds(width+50, height+40, 50, 20); 
  JF.add(jButton);
 //   jButton.setBackground(new Color(203,0,66));   
    jButton.setFocusable(false);	
    jButton.setHorizontalTextPosition(jButton.CENTER);
    jButton.setVerticalTextPosition(jButton.BOTTOM);
    jButton.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
    jButton.setIconTextGap(-20); //位置 		
    jButton.setForeground(Color.white);
    jButton.setBackground(new Color(203,0,66) );
    jButton.setBorder(BorderFactory.createEtchedBorder());
    JF.add(jButton);
    
    //-------獨立--------close----------------------/
    
    JButton close = new JButton();
		close.setBounds(width+110, height, 40, 18);
		JF.add(close);
		
		//	data.addActionListener((ActionListener) this);
		close.setText(close_add);
		close.setFocusable(false);	
		close.setHorizontalTextPosition(close.CENTER);
		close.setVerticalTextPosition(close.BOTTOM);
		close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
		close.setIconTextGap(-20); //位置 		
		close.setForeground(Color.white);
		close.setBackground(new Color(203,0,66) );
		close.setBorder(BorderFactory.createEtchedBorder());
		JF.add(close);
		
//--------------------------------------------------//			
    
	
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				// System.exit(0);
		//	JF.setExtendedState(JFrame.ICONIFIED);
				JF.dispose();
			}
		});
    
//---------------------------jButton----Click-----------------------------------------------//	     
		 
    
		  jButton.addActionListener(new ActionListener() { 
	            // Anonymous class. 
	  
	            public void actionPerformed(ActionEvent e) 
	            { 
	                // Override Method 
	  
	                // Declaration of String class Objects. 
	                String qual = " "; 
	                //---------music----------------//
	                // If condition to check if jRadioButton2 is selected. 
	                String op="開";
	             	String closure="關";
	             	
	             	
	       
	                // MessageDialog to show information selected radio buttons. 
	            	JF.dispose();
	            } 
	        }); 
		
//-----------------------------------------------------------------------//		
		
		  
		
		//-----------------------------------------------------//
  
  JF.setUndecorated(true);// 窗口去边框
	JF.setBackground(new Color(0,0,0,0));// 设置窗口为透明色 
	  JF.add(panel);
    JF.setVisible(true);            
} 







}