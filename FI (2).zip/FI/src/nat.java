import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import Translate.Translate_TXT;

public class nat {
	
	static int AISSYS=4; // 開始頁面訊息
	static int nation=94; // 語言
	static  int options =8;//選項頁面 開關音樂 與初始畫面
	static int  KEY=14; // 購買 序號
	static int result=8;// 介紹公司團隊頁面
	static int  _main=13; // 多少功能 class 
	static int _System=9; // class 整體視窗頁面 使用 參雜其他系統
	//-------------------------------------------------//
   
	static int Bitget_sales_possible=26; // class 整體視窗頁面 使用
	
	
	static int Bitget_Lending_System=16;// class 整體視窗頁面 使用
	
	
	static int  bitunix_system_only=95;// class 整體視窗頁面 使用
	
	
	static int   Query_currency_only=13;// class 整體視窗頁面 使用
    
	//----------------------選擇語言-----------------------------------//
	 static  String AIS="";
	static  String  article="article.wise.📑";
      static Translate      translate  = new  Translate();
  	//------------------------------------------------------//
      
      
      public static void Afrikaans() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Afrikaans";
  		translate.File_changed(AIS);
  		new AIS();
  	}
      public static void Albanian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Albanian";
    		translate.File_changed(AIS);
    		new AIS();
    	}
     
      public static void Amharic() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Amharic";
  		translate.File_changed(AIS);
  		new AIS();
  	}
   

      public static void Arabic() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Arabic";
  		translate.File_changed(AIS);
  		new AIS();
  	}
      
      

      public static void Armenian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Armenian";
  		translate.File_changed(AIS);
  		new AIS();
  	}
      
      

      public static void Assamese() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Assamese";
  		translate.File_changed(AIS);
  		new AIS();
  	}
      
      
      
      public static void Azerbaijani() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Azerbaijani";
    		translate.File_changed(AIS);
    		new AIS();
    	}
        
      
      public static void Belarusian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Belarusian";
    		translate.File_changed(AIS);
    		new AIS();
    	}
        
      
      public static void Bemba() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Bemba";
    		translate.File_changed(AIS);
    		new AIS();
    	}
         
      
      
      public static void Bengali() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Bengali";
    		translate.File_changed(AIS);
    		new AIS();
    	}
      
      

      
      
      
      
      public static void Bosnian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Bosnian";
  		translate.File_changed(AIS);
  		new AIS();
  	}   
      
      
      //--------------------10---------------------------------------------//
      
      
      
      
      
      
      
      
      public static void Bulgarian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
    		AIS="Bulgarian";
    		translate.File_changed(AIS);
    		new AIS();
    	}   
           
      public static void Burmese() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
  		AIS="Burmese";
  		translate.File_changed(AIS);
  		new AIS();
  	}   
         
      
  public static void Catalan() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Catalan";
		translate.File_changed(AIS);
		new AIS();
	}   
     
      
  public static void Chichewa() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Chichewa";
		translate.File_changed(AIS);
		new AIS();
	}   
   
  public static void Chinese_Simplified() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Chinese Simplified";
		translate.File_changed(AIS);
		new AIS();
	}      
      
      
  
  public static void Chinese_Traditional() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Chinese Traditional";
		translate.File_changed(AIS);
		new AIS();
	}      
     
  
  
  public static void Creole() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Creole";
		translate.File_changed(AIS);
		new AIS();
	}      
   
  public static void Croatian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Croatian";
		translate.File_changed(AIS);
		new AIS();
	}      
   
  
  public static void Czech() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Czech";
		translate.File_changed(AIS);
		new AIS();
	}      
 
  

  public static void Danish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Danish";
		translate.File_changed(AIS);
		new AIS();
	}      
 
  
  //----------------20--------------------------//

  public static void Dari() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Dari";
		translate.File_changed(AIS);
		new AIS();
	}      


  public static void Dutch() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Dutch";
		translate.File_changed(AIS);
		new AIS();
	}      

  public static void Dzongkha() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Dzongkha";
		translate.File_changed(AIS);
		new AIS();
	}      


	public static void English() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="English";
		translate.File_changed(AIS);
		new AIS();
	}
	

	
	public static void Estonian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Estonian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	public static void Fijian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Fijian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Finnish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Finnish";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void French() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="French";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	
	
	public static void Georgian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Georgian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	
	public static void German() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="German";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	//-----------------30------------------------------------//
	
	public static void Greek() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Greek";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Guarani() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Guarani";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Hausa() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Hausa";
		translate.File_changed(AIS);
		new AIS();
	}
	

	public static void Hebrew() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Hebrew";
		translate.File_changed(AIS);
		new AIS();
	}
	
	

	public static void Hindi() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Hindi";
		translate.File_changed(AIS);
		new AIS();
	}
	

	public static void Hungarian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Hungarian";
		translate.File_changed(AIS);
		new AIS();
	}
	

	public static void Indonesian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Indonesian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Irish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Irish";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Italian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Italian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Japan() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Japan";
		translate.File_changed(AIS);
		new AIS();
	}
	//------------------------40---------------------------------//
	
	public static void Kannada() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Kannada";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Khmer() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Khmer";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Kikongo() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Kikongo";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Kinyarwanda() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Kinyarwanda";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Korean() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Korean";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Lao() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Lao";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	public static void Latin() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Latin";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	
	public static void Latvian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Latvian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Lingala() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Lingala";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Lithuanian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Lithuanian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	//-------------50-----------------------//
	
	
	public static void Luganda() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Luganda";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Macedonian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Macedonian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Malagasy() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Malagasy";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Malay() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Malay";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Malayalam() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Malayalam";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Marathi() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Marathi";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Marshallese() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Marshallese";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Mongolian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Mongolian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Nepali() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Nepali";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Norwegian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Norwegian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	//------------------60--------------------------------------------//

	
	public static void Pashto() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Pashto";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Persian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Persian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Portuguese() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Portuguese";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Polish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Polish";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Punjabi() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Punjabi";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Romanian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Romanian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Russian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Russian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Samoan() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Samoan";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Sanskrit() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Sanskrit";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Serbian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Serbian";
		translate.File_changed(AIS);
		new AIS();
	}
	//---------------70--------------------------------//
	
	
	public static void Shona() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Shona";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Sinhala() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Sinhala";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Slovak() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Slovak";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Slovenian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Slovenian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Somali() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Somali";
		translate.File_changed(AIS);
		new AIS();
	}
	

	
	public static void Spanish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Spanish";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	public static void Swahili() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Swahili";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	
	
	public static void Swedish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Swedish";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	

	public static void Tamil() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Tamil";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Tetum() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Tetum";
		translate.File_changed(AIS);
		new AIS();
	}
	
	//-----------------80-------------------------------------//

	public static void Thai() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Thai";
		translate.File_changed(AIS);
		new AIS();
	}

	public static void Tongan() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Tongan";
		translate.File_changed(AIS);
		new AIS();
	}
	

	public static void Turkish() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Turkish";
		translate.File_changed(AIS);
		new AIS();
	}
	public static void Turkmen() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Turkmen";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Ukrainian() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Ukrainian";
		translate.File_changed(AIS);
		new AIS();
	}
	
	
	public static void Urdu() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Urdu";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Uzbek() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Uzbek";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Vietnamese() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Vietnamese";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Xhosa() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Xhosa";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void Yoruba() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Yoruba";
		translate.File_changed(AIS);
		new AIS();
	}
	//-------------------90--------------------------------//
	
	public static void Zulu() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="Zulu";
		translate.File_changed(AIS);
		new AIS();
	}
	
	public static void kazakh() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		AIS="kazakh";
		translate.File_changed(AIS);
		new AIS();
	}
	

	
	public static void AIS_read_name(String name)
	{
		AIS=name;
		
	}
	
	
	
	//----------------確定語言------------------------------------//
	
	
	public static String[] read_options( ) throws IOException{
		
        if(AIS=="")
        {
        	AIS="English";
        }
	String[] words = new String[options];
    double SUM;
    try {
	 
          BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/options.txt"));
          String str;
          int i=0;

          while ((str = in.readLine()) != null) {
          
        	   System.out.println(str+" i="+i);
              
        	   words[i]=str;
              i++;
          }
     
    } catch (IOException e) {
    }
	
	return words;
    
}
	
	
	
	
	
	
	
	
	
	
	
	//--------------------購買翻譯-------------------------------------//	
		public static String[] read_KEY( ) throws IOException{
			
	            if(AIS=="")
	            {
	            	AIS="English";
	            }
	            
	            
	            
	            
	            
	            
	            
	            
		    String[] words = new String[KEY];
		    double SUM;
		    try {
			 
		          BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/KEY.txt"));
		          String str;
		          int i=0;

		          while ((str = in.readLine()) != null) {
		          
		        	   System.out.println(str+" i="+i);
		              
		        	   words[i]=str;
		              i++;
		          }
		     
		    } catch (IOException e) {
		    }
			
		   
		    
			return words;
		    
		    
		    
		}

//--------------------國家翻譯-------------------------------------//	
	public static String[] read_nation( ) throws IOException{
		
            if(AIS=="")
            {
            	AIS="English";
            }
	    String[] words = new String[nation-1];
	    double SUM;
	    try {
		 
	          BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/nation.txt"));
	          String str;
	          int i=0;

	          while ((str = in.readLine()) != null) {
	          
	        	   System.out.println(str+" i="+i);
	              
	        	   words[i]=str;
	              i++;
	          }
	     
	    } catch (IOException e) {
	    }
		
	   
	    
		return words;
	    
	    
	    
	}


	//--------------------系統翻譯-------------------------------------//

	public static String[] read_System( ) throws IOException{

		  if(AIS=="")
          {
          	AIS="English";
          }
	String[] words = new String[_System];
	double SUM;
	try {
	 
	      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/System.txt"));
	      String str;
	      int i=0;

	      while ((str = in.readLine()) != null) {
	      
	    	   System.out.println(str+" i="+i);
	          
	    	   words[i]=str;
	          i++;
	      }
	 
	} catch (IOException e) {
	}



	return words;



	}

	//--------------------主要翻譯-------------------------------------//
	public static String[] read_main() throws IOException{
		  if(AIS=="")
          {
          	AIS="English";
          }

	String[] words = new String[_main];
	double SUM;
	try {
	 
	      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/main.txt"));
	      String str;
	      int i=0;

	      while ((str = in.readLine()) != null) {
	      
	    	   System.out.println(str+" i="+i);
	          
	    	   words[i]=str;
	          i++;
	      }
	 
	} catch (IOException e) {
	}
	return words;
	}


	
	


	//--------------------主畫面翻譯-------------------------------------//	
	
	
	public static String[] read_AISSYS() throws IOException{
		  if(AIS=="")
        {
        	AIS="English";
        }

	String[] words = new String[AISSYS];
	double SUM;
	try {
	 
	      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/AISSYS.txt"));
	      String str;
	      int i=0;

	      while ((str = in.readLine()) != null) {
	      
	    	   System.out.println(str+" i="+i);
	          
	    	   words[i]=str;
	          i++;
	      }
	 
	} catch (IOException e) {
	}
	return words;
	}

	

	
	
	//--------------------公司介紹翻譯-------------------------------------//	
	public static String[] read_result() throws IOException{
		  if(AIS=="")
      {
      	AIS="English";
      }

	String[] words = new String[result];
	double SUM;
	try {
	 
	      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/result.txt"));
	      String str;
	      int i=0;

	      while ((str = in.readLine()) != null) {
	      
	    	   System.out.println(str+" i="+i);
	          
	    	   words[i]=str;
	          i++;
	      }
	 
	} catch (IOException e) {
	}
	return words;
	}	
	
	
	
	
//--------------------系統內容-----------------------------------------------//	

	
	public static String[] get_Bitget_Lending_System() throws IOException{
		
		  if(AIS=="")
	      {
	      	AIS="English";
	      }

		String[] words = new String[Bitget_Lending_System];
		double SUM;
		try {
		 
		      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/Bitget Lending System.txt"));
		      String str;
		      int i=0;

		      while ((str = in.readLine()) != null) {
		      
		    	   System.out.println(str+" i="+i);
		          
		    	   words[i]=str;
		          i++;
		      }
		 
		} catch (IOException e) {
		}
		return words;
		
	}
	public static String[] get_bitunix_system_only() throws IOException{
		
		  if(AIS=="")
	      {
	      	AIS="English";
	      }

		String[] words = new String[bitunix_system_only];
		double SUM;
		try {
		 
		      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/bitunix system only.txt"));
		      String str;
		      int i=0;

		      while ((str = in.readLine()) != null) {
		      
		    	   System.out.println(str+" i="+i);
		          
		    	   words[i]=str;
		          i++;
		      }
		 
		} catch (IOException e) {
		}
		return words;
		
	}

	public static String[] get_Bitget_sales_possible() throws IOException{
		
		  if(AIS=="")
	      {
	      	AIS="English";
	      }

		String[] words = new String[Bitget_sales_possible];
		double SUM;
		try {
		 
		      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/Bitget sales possible.txt"));
		      String str;
		      int i=0;

		      while ((str = in.readLine()) != null) {
		      
		    	   System.out.println(str+" i="+i);
		          
		    	   words[i]=str;
		          i++;
		      }
		 
		} catch (IOException e) {
		}
		return words;
		
	}

	

	public static String[] get_Query_currency_only() throws IOException{
		
		  if(AIS=="")
	      {
	      	AIS="English";
	      }

		String[] words = new String[Query_currency_only];
		double SUM;
		try {
		 
		      BufferedReader in = new BufferedReader(new FileReader(article+"/"+AIS+"/Query currency only.txt"));
		      String str;
		      int i=0;

		      while ((str = in.readLine()) != null) {
		      
		    	   System.out.println(str+" i="+i);
		          
		    	   words[i]=str;
		          i++;
		      }
		 
		} catch (IOException e) {
		}
		return words;
		
	}




















}

