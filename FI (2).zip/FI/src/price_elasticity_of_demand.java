
public class price_elasticity_of_demand {

}
