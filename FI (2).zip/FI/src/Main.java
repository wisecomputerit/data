import java.awt.BorderLayout;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;



public class Main {

	
		public static void pale  () throws IOException
		{
			
			//C:\Users\zxc78\OneDrive\Desktop\image_file
		
				File article = new File("article.wise.📑");   
			    article.mkdir();
			    			
			    File pdf = new File("PDF.wise.📒");   
			    pdf.mkdir();
			    
			    File KNN = new File("KNN");   
			    KNN.mkdir();
			    
	
			    File Comparative = new File("KNN/Comparative.information");   
			    Comparative.mkdir();
			    
			    
			    File translate = new File("translate.wise.💬");   
			   	 translate.mkdir(); 
			    
			    	
			  //--------------------------------------------------------------------------------//
			  /*設置路徑及資料夾*/
			    File dir = new File("data.wise.🗄️");        
			    File image_path = new File("data.wise.🗄️/illustrate");     
			    /*建立單一資料夾的方法  mkdir();    */
			    dir.mkdir();    
			    /*即使沒母資料夾也會一起創建的方法 mkdirs();*/
			    image_path.mkdirs();    
			    /*在路徑後面添加要建立的檔案名稱及副檔名*/     
			    
			    /*將dir_image的value轉成String*/
			    String workDirBase = image_path.toString();    

	     
				Path p = Paths.get(workDirBase);    //路徑設定
	            /*確認資料夾是否存在*/
	            if (Files.exists(p)) {
	            
	            }
	            if (!Files.exists(p)) {
	                /*不存在的話,直接建立資料夾*/
	                Files.createDirectory(p);
	       
	        }
			
			
		}
		
	
}
