import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.prefs.Preferences;

public class AutoStart {

	public static void main(String[] args) {
		// TODO 自動產生的方法 Stub
	      // 設置註冊表條目，將應用程序添加到開機啟動
        Preferences prefs = Preferences.userRoot().node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
        String programName = "WiseFinancialSystem"; // 您的應用名稱
        String command = "java -jar  C:\\Users\\zxc78\\OneDrive\\Desktop\\experimentalfield\\SystemTrayExample.jar"; // 程式的啟動命令
        
     //  java -jar   C:\Users\zxc78\OneDrive\Desktop\experimental field.wise\SystemTrayExample.jar
        // java -jar SystemTrayExample.jar
        prefs.put(programName, command);
        String existingCommand = prefs.get(programName, null);
        
        boolean exists =checkRegistryKeyExists("Software\\Microsoft\\Windows\\CurrentVersion\\Run",command);
   
        System.out.println("程序設置為開機自啟動。"+existingCommand + "   " +exists);
        
        
        /*
        try {
            // Command to execute (for example, 'dir' or 'java -version')
            List<String> Command = Arrays.asList("cmd.exe", "/c",  "java -version"); // This lists the directory contents
            
            // Create a ProcessBuilder
            ProcessBuilder processBuilder = new ProcessBuilder(Command);
            
            // Redirect output to the console
            processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
            processBuilder.redirectError(ProcessBuilder.Redirect.INHERIT);
            
            // Start the process
            Process process = processBuilder.start();
            
            // Wait for the command to finish
            process.waitFor();
            
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        
        
        
        java -jar "C:\Users\zxc78\OneDrive\Desktop\experimental field.wise\SystemTrayExample.jar"

        */
        
	}
	
	 private static boolean checkRegistryKeyExists(String path, String key) {
		 Preferences prefs = Preferences.systemRoot().node(path);
		 String[] keys = {};
		 try {
		 keys = prefs.keys();
		 } catch (Exception e) {
		 // Handle error
		 }
		 for (String k : keys) {
		 if (k.equals(key)) {
		 return true;
		 }
		 }
		 return false;

		 }

}
