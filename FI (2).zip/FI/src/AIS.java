import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import System_options.options;
import Translate.Translate_TXT;
import initial.window.demo_wise;
import music.music;





public class AIS {

	
	private JPanel contentPane,ContentPane;
	private JTextField  A1,A2,B1;
	private JLabel lblId, lblPwd;
	private JButton btnLogin, BtnLogin,check_out,Translate,System_options;

	  public static   String start ="startbutton.wav";

	  public static   String option ="optionbutton.wav";
	  
	  
	 
	  
	  
	  public static  String AIS = "AIS.jpg";  // 開始圖示
	  
	  public static  String cover = "cover.png";// 背景圖片
	  
	  
	  
	  static Translate t= new Translate();  //翻譯
	  
	
	  public static  JFrame JF ; // 視窗
	  
	  public static  String System2 = "Wise Financial System 3.0";// 視窗 名稱
	  
	  public static  String PDF = "PDF.wise.📒";
	  
	  
	  public static demo_wise main_Loading = new demo_wise();
	  
	  public static  options  System_op = new options();
	  
	  public static  Color ColorsetBackground_AIS = new Color(0,183,100); //背景顏色 綠色
	    
	  public static  Color getColor_JFrame = new Color(68,208,145); //背景顏色 綠色
	  
	  

	  
		 public  AIS() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		
			 
			    String translatename  =  read("translate.wise.💬\\translate.txt"); // 讀取翻譯資料庫
			//   JOptionPane.showMessageDialog(null,translatename,"" ,JOptionPane.INFORMATION_MESSAGE);		
			  
			    nat  n = new nat(); 
			   n.AIS_read_name(translatename);// 送資料給翻譯系統 然後 AIS 全體 new AIS
	
		
			   
	      String  []AISSYS  =nat.read_AISSYS(); // 讀取初始頁面訊息
				
			
			 
			// Thread.sleep(500);
			    JF=new JFrame(System2);
			    JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				JF.setBounds(100, 100, 600, 280);
				contentPane = new JPanel();
				JF.setContentPane(contentPane);
	
				contentPane.setLayout(null);
				JF.setResizable(false);
				
				
		
			    final List<Image> icons = new ArrayList<Image>();
			    
			      String imagePath = "AIS.jpg";
		         File imageFile = new File(imagePath);
			     icons.add(ImageIO.read(imageFile));
			    
			    JF.setIconImages(icons); 
			    JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	                       // 寬 長
			 
			    
	
			    
			    
				BtnLogin = new JButton(AISSYS[0]);
				BtnLogin.setBounds(300, 220, 140, 25);
				contentPane.add(BtnLogin);
			    
		
				
				//	data.addActionListener((ActionListener) this);
				BtnLogin.setText(AISSYS[0]);
				BtnLogin.setFocusable(false);	
				BtnLogin.setHorizontalTextPosition(BtnLogin.CENTER);
				BtnLogin.setVerticalTextPosition(BtnLogin.BOTTOM);
				BtnLogin.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
				BtnLogin.setIconTextGap(-20); //位置 		
				BtnLogin.setForeground(Color.white);
				BtnLogin.setBackground(ColorsetBackground_AIS );
					BtnLogin.setBorder(BorderFactory.createEtchedBorder());
					contentPane.add(BtnLogin);
				
				
				
				Translate = new JButton(AISSYS[1]);
				Translate.setBounds(80, 220, 140, 25);
				contentPane.add(Translate);
			
				//	data.addActionListener((ActionListener) this);
				Translate.setText(AISSYS[1]);
				Translate.setFocusable(false);	
				Translate.setHorizontalTextPosition(Translate.CENTER);
				Translate.setVerticalTextPosition(Translate.BOTTOM);
				Translate.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
				Translate.setIconTextGap(-20); //位置 		
				Translate.setForeground(Color.white);
				Translate.setBackground(ColorsetBackground_AIS );
				Translate.setBorder(BorderFactory.createEtchedBorder());
					contentPane.add(Translate);
				
					
					System_options = new JButton(AISSYS[2]);
					System_options.setBounds(300, 190, 100, 25);
					contentPane.add(System_options);
				
					//	data.addActionListener((ActionListener) this);
					System_options.setText(AISSYS[2]);
					System_options.setFocusable(false);	
					System_options.setHorizontalTextPosition(System_options.CENTER);
					System_options.setVerticalTextPosition(System_options.BOTTOM);
					System_options.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
					System_options.setIconTextGap(-20); //位置 		
					System_options.setForeground(Color.white);
					System_options.setBackground(ColorsetBackground_AIS );
					System_options.setBorder(BorderFactory.createEtchedBorder());
						contentPane.add(System_options);
			
						
						JButton close = new JButton();
					//	close.setBounds(510, 20, 60, 25);
						close.setBounds(510, 20, 50, 20);
						contentPane.add(close);
						
						//	data.addActionListener((ActionListener) this);
						close.setText(AISSYS[3]);
						close.setFocusable(false);	
						close.setHorizontalTextPosition(close.CENTER);
						close.setVerticalTextPosition(close.BOTTOM);
						close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
						close.setIconTextGap(-20); //位置 		
						close.setForeground(Color.white);
						close.setBackground(new Color(203,0,66) );
						close.setBorder(BorderFactory.createEtchedBorder());
					     contentPane.add(close);
							
					
						 /*
		        setDefaultCloseOperation(EXIT_ON_CLOSE);
		        setLocationRelativeTo(null);
		        setSize(300, 300);
		        setResizable(false);
		        getContentPane().setLayout(null);
		        */
		        
		        
		        JPanel panel = new ImagePanel();
		        panel.setBounds(0, 0, 600, 300);
		        JF.getContentPane().add(panel);
		        
			
				
				

				/*--------------------------------------------------------*/
				JButton jb = new JButton();
				jb.setBounds(500, 200, 100, 25);
				jb.setSize(50, 50);//设置按钮大小
				String path = "AIS.jpg";
				//设置图片路径，实践的话根据自己的图片路径另加设置；我这个图片是个笑脸
				ImageIcon icon = new ImageIcon(path);//根据路径创建图标
				Image temp1 = icon.getImage().getScaledInstance(jb.getWidth(),jb.getHeight(), icon.getImage().SCALE_DEFAULT);
				//新建图片，大小调制成和按钮大小一样大
				//getScaledInstance()方法返回的是一个图片，后面的参数在程序下有注解。
				icon = new ImageIcon(temp1);
				//将图片另引用为图标
				jb.setIcon(icon);
				//将图标加载到按钮之上
				contentPane.add(jb);		
				

				//---------------------------------------------------------//
			//	Systemclose
				
				
				
		
					
				
				
				
				
				
				
				//-------------------------------------------------//
				/*
			        JPanel Panel = new ImagePanel();
			        Panel.setBounds(0, 0, 600, 300);
			        JF.getContentPane().add(Panel);
				*/
				
				
			
				
				
				
		
				
				
				
				/*
				JButton	BtnLogin = new JButton();
				BtnLogin.setBounds(400, 200, 100, 25);
				BtnLogin.setSize(50, 50);//设置按钮大小
				String Path = "2.png";
				//设置图片路径，实践的话根据自己的图片路径另加设置；我这个图片是个笑脸
				ImageIcon Icon = new ImageIcon(Path);//根据路径创建图标
				Image Temp1 = Icon.getImage().getScaledInstance(BtnLogin.getWidth(),
						BtnLogin.getHeight(), Icon.getImage().SCALE_DEFAULT);
				//新建图片，大小调制成和按钮大小一样大
				//getScaledInstance()方法返回的是一个图片，后面的参数在程序下有注解。
				Icon = new ImageIcon(Temp1);
				//将图片另引用为图标
				BtnLogin.setIcon(Icon);
				//将图标加载到按钮之上
				contentPane.add(BtnLogin);
				
				*/
				
				
				
				
				
				
				
				
				
				
				
				/*--------------------------------------------------------*/
			//	((RootPaneContainer) panel).setContentPane(jb);
				/*
				BtnLogin = new JButton("退出系統");
				BtnLogin.setBounds(290, 220, 100, 25);
				contentPane.add(BtnLogin);
				
				
				
				btnLogin = new JButton("進入系統");
				btnLogin.setBounds(150, 220, 100, 25);
				contentPane.add(btnLogin);
				*/
				System_options.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						try {
							main_start();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
						
						
						try {
					
							String  []options  =nat.read_options();	
							System_op.man(JF,options);
							
				
							
							
							
							
						} catch (IOException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
					
						
					}
				});  
				
			
				close.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {	
						
						

						 String data = "data.wise.🗄️";
						 String tray ="main.txt";
	

				        String output_HA = data+"\\"+tray;
					     Path path = Paths.get(output_HA);

					            // 创建文件，如果文件不存在
					            if (!Files.exists(path)) {
					                try {
										Files.createFile(path);
									} catch (IOException e1) {
										// TODO 自動產生的 catch 區塊
										e1.printStackTrace();
									}
					                System.out.println("文件已创建: " + path);
					            } else {
					                System.out.println("文件已经存在: " + path);
					            }
					    
						        
					            System.out.print("停滯使用\n");
								  try (FileWriter writer = new FileWriter(data+"\\"+tray)) {
							            writer.write("0");  // 寫入內容到文件
								  } catch (IOException e1) {
									// TODO 自動產生的 catch 區塊
									e1.printStackTrace();
								}

						JF.dispose();
				//		System.exit(1);
						
					}
				});
				
				jb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					
				
						try {
							main_option();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						main_min main_min=new main_min();
					
					
							try {
								main_min.man();
							} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
									| InterruptedException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
					
				/*
						
						  Main main = new Main ();    	
							try {
								
								main.main();	
							} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}		
					
							*/
					}
				});
				
		
			
				  
				BtnLogin.addActionListener(new ActionListener() { //按鈕
					public void actionPerformed(ActionEvent e) {
					
					
				
					
					
			         
							 KEY key;
							try {
								main_option();
								key = new KEY();
						    	  key.Frame(JF);
							} catch (IOException | UnsupportedAudioFileException | LineUnavailableException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
						
			        
						
					
							
						//	JF.dispose();
						
						
					

					}

					

				});
			
				Translate.addActionListener(new ActionListener() { //按鈕
					public void actionPerformed(ActionEvent e) {

					
						try {
						
							main_option();
							
							Translate  tr = new Translate();
							try {
								tr.Delete_window(JF);
								tr.man();
							
								
							} catch (InterruptedException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
						//	JF.dispose();
						//	 new AIS();
						//	JF.dispose();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

					}

				});
				
	
		    
		JF.setUndecorated(true);// 窗口去边框

		JF.setBackground(new Color(0,0,0));// 设置窗口为透明色   
				JF.setVisible(true);	
		    }
	
		public static void main(String[] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException, InterruptedException {
			// TODO Auto-generated method stub
			
		
			/*
		
			
			
		
		     Thread.sleep(500);
		     */
			
		     
		     String Key_neame ="data.wise.🗄️";
		     String Key_neamelocal="local.txt";
		     
		     String Key_neametray="tray.txt";
			 String Key_main ="main.txt";
   		     String dataneametray="options.txt";
		     String Switch =   main_Loading.getSwitch_options_Loading();
		 
		     
	
		        String output_HA = Key_neame+"\\"+"input_HA.txt";
		     Path path = Paths.get(output_HA);

		        try {
		            // 创建文件，如果文件不存在
		            if (!Files.exists(path)) {
		                Files.createFile(path);
		                System.out.println("文件已创建: " + path);
		            } else {
		                System.out.println("文件已经存在: " + path);
		            }
		        } catch (IOException e) {
		            System.out.println("发生错误: " + e.getMessage());
		        }
		        
		        
	
	
		     
			     boolean KEYTrue=KEY.read_KEY_time();
		     
		if(	KEYTrue ==true)
		{
			System.out.print("客戶繼續使用\n");
			  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neamelocal)) {
		            writer.write("0");  // 寫入內容到文件

		        } catch (IOException e) {
		            e.printStackTrace();
		        }
			
		}
		if(	KEYTrue ==false)
		{
			
			System.out.print("客戶不能再用\n");
			
			
			  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neamelocal)) {
		            writer.write("1");  // 寫入內容到文件

		        } catch (IOException e) {
		            e.printStackTrace();
		        }
			
		}
	    	
		     
		     
	//	     System.out.print(Switch);
		     if(Switch.equals("關"))
		     {
		    	 
		    	   String AIS_KEY = KEY.BufferedReaderTXT(Key_neame+"\\"+Key_main);
				     if(AIS_KEY.equals("0"))
				     {
				    	 
				    	 
				    	 
						   	new AIS();
				    	 
				     }
		    	   
		    	 

		    	 
		
		  // 	 Translate_TXT.main();
		  
		    	
		    	 
		     }
		     if( Switch.equals("開") )
		     {
		    	 
		    	
		    	//	 new AIS();
		
		    	//	Translate A = new Translate();
	                    
		    		   String AIS_KEY = KEY.BufferedReaderTXT(Key_neame+"\\"+Key_main);
					     if(AIS_KEY.equals("0"))
					     {
					    	 
					    	 
					    		main_Loading.main(800,System2);
							   	new AIS();
					    	 
					     }
	
		   	 
		   	 
		   	 
		     }
		     

         	
			  //  String dataKEYtray = KEY.BufferedReaderTXT(dataKey+"\\"+dataneametray);
			    
			    
				    String dataKey ="data.wise.🗄️";

	    
	                	
	 			    String dataKEYtray = KEY.BufferedReaderTXT(dataKey+"\\"+dataneametray);
		     
	 			    System.out.print(dataKEYtray+"dataKEYtray");
				    if(dataKEYtray.equals("1"))
				    {
				  	  //----------------解決重複打開問題---------------------------//
				        String output_HA_path_tray = Key_neame+"\\"+Key_neametray;
				     Path path_tray  = Paths.get(output_HA_path_tray);
				    
				     // 创建文件，如果文件不存在
			            if (!Files.exists(path_tray)) {
			                try {
								Files.createFile(path_tray);
							} catch (IOException e1) {
								// TODO 自動產生的 catch 區塊
								e1.printStackTrace();
							}
			                System.out.println("文件已创建: " + path_tray);
			            } else {
			                System.out.println("文件已经存在: " + path_tray);
			            }
			    
			            
			            
					    String KEYtray = KEY.BufferedReaderTXT(Key_neame+"\\"+Key_neametray);
					  
					  
					    System.out.print("KEYtray =  "+KEYtray);
					    
						  try (FileWriter writer = new FileWriter(Key_neame+"\\"+Key_neametray)) {   //先全部等於1 之前 KEYtray 有保留 可以放心
					            writer.write("1");  // 寫入內容到文件
						  } catch (IOException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}

						  if(KEYtray.equals("0")) // 使用KEYtray
						  {
							  
							 	SystemTrayExample.driver(); // 驅動程序
						  }
						
				    	
				    }
				
		   
		}
	
		  public static String read(String fileName){
			  
			  String Name = null;
		        FileReader fr = null;
		        try {
		            fr = new FileReader(fileName);
		        } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        }
		        BufferedReader br = new BufferedReader(fr);
		        String tmp = null;

		        try {
		            while (((tmp = br.readLine()) != null)) {
		   
		            	Name=tmp;
		            	
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        } finally {
		            try {
		                br.close();
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
				return Name;

		    }
		
	
		
		
		public static void main_start() throws UnsupportedAudioFileException, IOException, LineUnavailableException, InterruptedException
		{	
			
			music m  =new  music();
			  String Switch =   m.getSwitch_options_music();

			     if(Switch.equals("開"))
			     {
			    	 
			   	  
					  //   Thread.sleep(1000);
						File Afile = new File(start);
					  AudioInputStream AaudioStream = AudioSystem.getAudioInputStream(Afile);
					  Clip Aclip = AudioSystem.getClip();
					  Aclip.open(AaudioStream);
					  Aclip.setMicrosecondPosition(0);
					  Aclip.start();
			     }
			     if( Switch.equals("關") )
			     {
			    	 
					  
					  
					  //   Thread.sleep(1000);
						File Afile = new File("System.wav");
					  AudioInputStream AaudioStream = AudioSystem.getAudioInputStream(Afile);
					  Clip Aclip = AudioSystem.getClip();
					  Aclip.open(AaudioStream);
					  Aclip.setMicrosecondPosition(0);
					  Aclip.start();
			     }
		}

		public static void main_option() throws UnsupportedAudioFileException, IOException, LineUnavailableException
		{	
			
			
			
			  music m  =new  music();
			  String Switch =   m.getSwitch_options_music();
			  
			  System.out.print(Switch);
			   if(Switch.equals("開"))
			     {
			    	 
			   	  
					  //   Thread.sleep(1000);
						File Afile = new File(option);
					  AudioInputStream AaudioStream = AudioSystem.getAudioInputStream(Afile);
					  Clip Aclip = AudioSystem.getClip();
					  Aclip.open(AaudioStream);
					  Aclip.setMicrosecondPosition(0);
					  Aclip.start();
			     }
			     if( Switch.equals("關") )
			     {
			    	 
					  
					  
					  //   Thread.sleep(1000);
						File Afile = new File("System.wav");
					  AudioInputStream AaudioStream = AudioSystem.getAudioInputStream(Afile);
					  Clip Aclip = AudioSystem.getClip();
					  Aclip.open(AaudioStream);
					  Aclip.setMicrosecondPosition(0);
					  Aclip.start();
			     }
			    
			    
		}
	
	
		  
		  
		public static void Muisc_start() throws UnsupportedAudioFileException, IOException, LineUnavailableException  {
			File file = new File(start); // 音樂
			  AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
			  Clip clip = AudioSystem.getClip();
			  clip.open(audioStream);
				clip.setMicrosecondPosition(0);
				clip.start();
		}	
		
		
		public static void Muisc_option() throws UnsupportedAudioFileException, IOException, LineUnavailableException  {
		
			
			
			
			File file = new File(option); // 音樂
			  AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
			  Clip clip = AudioSystem.getClip();
			  clip.open(audioStream);
				clip.setMicrosecondPosition(0);
				clip.start();
		}	
		
		public static void deleteAll(File path) { // 刪除全部
	        if (!path.exists()) {
	            return;
	        }
	        if (path.isFile()) {
	            path.delete();
	            return;
	        }
	        File[] files = path.listFiles();
	        for (int i = 0; i < files.length; i++) {
	            deleteAll(files[i]);
	        }
	        path.delete();
	    }
		
		public static void FilePath(String name) { // 建立

		    
	    File KNN = new File(name);   
	    KNN.mkdir();
	    
   
   	    
	    
	    
		}
	
		
		public static StringBuffer getFileList(String folderPath){
	        //String folderPath = "C:\\";//資料夾路徑
	        StringBuffer fileList = new StringBuffer();
	            try{
	               java.io.File folder = new java.io.File(folderPath);
	               String[] list = folder.list();          
	                         for(int i = 0; i < list.length; i++){
	                             fileList.append(list[i]).append("\n");
	                        }
	                }catch(Exception e){
	                   //   System.out.println("'"+folderPath+"'此資料夾不存在");
	                }
				
	         //       System.out.println(fileList);
	            return fileList;
	         
	        }
	
		
		
		
		
		
	    class ImagePanel extends JPanel {
	        public void paint(Graphics g) {
	            super.paint(g); // 封面 cover
	            ImageIcon icon = new ImageIcon("cover.png");
	            g.drawImage(icon.getImage(), 0, 0, 600, 300, this);
	        }
		    }






		public void dispose( ) {
			// TODO Auto-generated method stub
			JF.dispose();
		}
		
		public static void chome(String Url) {

			String url = Url;
			// ------------------------------------------------------//

			// ------------------------------------------------------//
			try {

				java.net.URI uri = java.net.URI.create(url);
				// 獲取當前系統桌面擴充套件
				java.awt.Desktop dp = java.awt.Desktop.getDesktop();
				// 判斷系統桌面是否支援要執行的功能
				if (dp.isSupported(java.awt.Desktop.Action.BROWSE)) {
					dp.browse(uri);
					// 獲取系統預設瀏覽器開啟連結
				}
			} catch (java.lang.NullPointerException e) {
				// 此為uri為空時丟擲異常
				e.printStackTrace();
			} catch (java.io.IOException e) {
				// 此為無法獲取系統預設瀏覽器
				e.printStackTrace();
			}

			// ------------------------------------------------------//
			try {
				Thread.sleep(3000);

				// 2秒 確定網址

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 設定 兩秒後啟關閉 瀏覽器

			// -----關閉-------------------------------------------------//

		}
	


}
