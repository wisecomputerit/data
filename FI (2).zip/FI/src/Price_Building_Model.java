
public class Price_Building_Model {

}
