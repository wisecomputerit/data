import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;

import initial.window.demo_wise;

public class SystemTrayExample {

static String UELname ="https://wisecomputerit.github.io/";	
	
static String data = "data.wise.🗄️";
static String tray ="tray.txt";
	
    public static void driver() {
   
    	
    	
	     
	
	        
 
        if (!SystemTray.isSupported()) {
            System.out.println("系統不支持托盤！");
            return;
        }

   
        
        // Create the system tray
        SystemTray systemTray = SystemTray.getSystemTray();

        // Create an image for the tray icon (use absolute path or make sure it's in the right location)
        String imagePath = "AISOK16x16.jpg";  // Full path to the image
        Image image = Toolkit.getDefaultToolkit().getImage(imagePath);

        // Create a popup menu for the tray icon
        PopupMenu popupMenu = new PopupMenu();

        // Create the "Open Wise Financial System 3.0" menu item
        MenuItem settingsItem = new MenuItem("Open Wise Financial System 3.0");
        Font font = new Font("微软雅黑", Font.PLAIN, 12);
        if (font.getName().equals("Dialog")) {
            font = new Font("Arial", Font.PLAIN, 12);  // Fallback font
        }
        settingsItem.setFont(font);
        settingsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
              	try {
					new AIS();
				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
					// TODO 自動產生的 catch 區塊
					e1.printStackTrace();
				}
         //       JOptionPane.showMessageDialog(null, "設置操作！");
                
                
                System.out.println("進入設置");
            }
        });
        popupMenu.add(settingsItem);
        
        //---------------------------------------------//
        
        
        // Create the "Open Wise Financial System 3.0" menu item
        MenuItem Official  = new MenuItem("Official website");
        Font font_Official  = new Font("微软雅黑", Font.PLAIN, 12);
        if (font_Official.getName().equals("Dialog")) {
        	font_Official = new Font("Arial", Font.PLAIN, 12);  // Fallback font
        }
        Official.setFont(font_Official);
        Official.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            
            	
            	
            	
            	
            	
         
            	AIS.chome(UELname);
            	
            	
         //       JOptionPane.showMessageDialog(null, "設置操作！");
                
                
             //   System.out.println("進入設置");
            }
        });
        popupMenu.add(Official);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        // Create the "Exit" menu item
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.setFont(font);  // Use the same font
        exitItem.addActionListener(e -> {
			
			
        	  
	        String output_HA = data+"\\"+tray;
	     Path path = Paths.get(output_HA);

	            // 创建文件，如果文件不存在
	            if (!Files.exists(path)) {
	                try {
						Files.createFile(path);
					} catch (IOException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
	                System.out.println("文件已创建: " + path);
	            } else {
	                System.out.println("文件已经存在: " + path);
	            }
	    
		        
	            System.out.print("停滯使用\n");
				  try (FileWriter writer = new FileWriter(data+"\\"+"tray.txt")) {
			            writer.write("0");  // 寫入內容到文件
				  } catch (IOException e1) {
					// TODO 自動產生的 catch 區塊
					e1.printStackTrace();
				}

			 
        	System.out.print("Exit = 0\n");
		   
		    System.exit(0);  // Exit the program when clicked
		    

		    
		    
		    
		});
        popupMenu.add(exitItem);

        // Create the tray icon with the image and the popup menu
        TrayIcon trayIcon = new TrayIcon(image, "Java 系統托盤示例", popupMenu);

        // Add an action listener for the tray icon (when clicked)
        trayIcon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               // JOptionPane.showMessageDialog(null, "您點擊了系統托盤圖標！");
                
               	try {

        					new AIS();
        				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException  e1) {
        					// TODO 自動產生的 catch 區塊
        					e1.printStackTrace();
        				}
            }
        });

        // Add the tray icon to the system tray
        try {
            systemTray.add(trayIcon);
        } catch (AWTException e) {
            System.err.println("無法添加托盤圖標：" + e.getMessage());
        }

        // Keep the application running to prevent the tray icon from disappearing
        try {
            Thread.sleep(1000000);  // Sleep for a long time to keep the tray icon active
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    
    }  // 以針對舊版本的 Java。 啟用
}
