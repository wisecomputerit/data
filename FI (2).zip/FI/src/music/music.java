package music;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class music {

	static public String fileName ="music.wise.🎵/music.txt";


	public static String  getSwitch_options_music( ) //獲取取開關
	{
		  String Name = null;
	        FileReader fr = null;
	        try {
	            fr = new FileReader(fileName);
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
	        BufferedReader br = new BufferedReader(fr);
	        String tmp = null;

	        try {
	            while (((tmp = br.readLine()) != null)) {
	   
	            	Name=tmp;
	            	
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                br.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
			return Name;
	}
	
}
