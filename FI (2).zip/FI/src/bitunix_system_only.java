import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class bitunix_system_only {
	//---------JFrame-------------------// 
	public static JFrame f;  //制定視窗
    static  Color getColor = AIS.getColor_JFrame; //制定視窗 顏色     //需更改
      public static  Color getColor_JButtonTXT = new Color(254,186,41); //背景顏色JButtonTXT  黃色  //需更改

    //-----------------------------------------------//
	public static  int w = 680+200; //制定大小
	public static  int h = 680;
	
	public static  int win_JFrameWidth = 100,  win_JFramegetHeight = 30;// 位置
	

	//-----------Translate----------------// 
    static   String[] TranslateSystem; // 制定翻譯視窗系統
    static String[] bitunix_system_only; // 制定翻譯功能系統 //需更改
    //-----------------按鈕URL --------------------------//
    
    static   String UELname="https://www.bitunix.com/zh-tw";     //需更改
 
	//-----------JTextField----輸入格------------// 
     static  JTextField[] JFtxt   =new JTextField [4]; // 需要多少
    
    
    
    
    //Bitget sales possible
    
    
    
    
    
    
    
    
    
    
    
    public static JPanel menu(JFrame f) throws IOException {
   
    	TranslateSystem =nat.read_System( );
	     
		 JPanel menu=new JPanel(); 
		 menu.setBounds(w/3-20,h-h/7,w,h/11); //位置  // 大小  
		 menu.setBackground(new Color(240,240,240) );
		 menu.setLayout(null); // 使用絕對定位
		//	f.setContentPane(menu);

			int menu_H  = h-h/7;
			int menu_W=w/3-20 ;
			
			
		

        //--------------JPanel----menu.wsie----------------------//
	     
	
			
			
	       
	//------------------JButton--menu--------------Start------------------//   
		     JButton b1=new JButton(bitunix_system_only[2]);     //  OK
		 

		       
		     b1.setBounds(270,10,100,25);  
		     b1.setForeground(getColor);
		     b1.setBackground(Color.white);  
//		     b1.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//		     b2.setBorderPainted(false); // 移除邊框
		     b1.setFocusPainted(false); // 移除焦點框
		     menu.add(b1);

		     	b1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
				           
					
				
						try {
							AIS.main_start(); //聲音
							
							Create_profile();//創建檔案
							
							
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
						
						

						
						
						String marketprice = JFtxt[0].getText();
						double x = Double.parseDouble(marketprice);
						String loan = JFtxt[1].getText();
						double Opening_price = Double.parseDouble(loan); // 開倉價格
						String interest_rate = JFtxt[2].getText();
						double target_price = Double.parseDouble(interest_rate);// 目標價格
						String YY = JFtxt[3].getText();
						double y = Double.parseDouble(YY);// 分成等分
						// ------------------------------------------------------------------//
						double A = x / 2;
				//		String[] gender = { "輸入 0 Bitget 365日売買可能", "輸入 1 Bitget 借貸系統", "輸入 2 bitunix 系統專用", "輸入 3 查詢貨幣專用"};
						if (Opening_price < target_price) { // 漲幅比較

							double XX = Opening_price - target_price;
							double Open_wallet = A / y;
							double result_sqrt = 200 / y;
							double[] Result_sqrt = new double[(int) y];
							String[] Gender = new String[(int) y];
							String GGender = "";
							for (int i = 0; i < y; i++) {
								Gender[i] = bitunix_system_only[9] + (i + 1) +
										"  "+bitunix_system_only[10] + Open_wallet +
										"  "+bitunix_system_only[11] +
										"  "+bitunix_system_only[12] + (result_sqrt * (i + 1))
										+ 		bitunix_system_only[13]+"\n";
								GGender = GGender + Gender[i];
								Result_sqrt[i] = result_sqrt * (i + 1);
							}

							JOptionPane.showMessageDialog(null,  GGender,
									TranslateSystem[3], JOptionPane.INFORMATION_MESSAGE);

							// --------------------------------------------------------------------//
							int mType = JOptionPane.INFORMATION_MESSAGE;
							String in1 = JOptionPane.showInputDialog(null, bitunix_system_only[15],  bitunix_system_only[14], mType);
							double target_Price = Double.parseDouble(in1);// 預計目標價格
							double Target_Price = -(target_Price - target_price);// 我要獲利之間價差
							if (in1 == null) {
								
								JOptionPane.showMessageDialog(null, "關閉 ");
								
								
							} else {
								String[] DDDDD = new String[200];
								String DDDD = "";
								if (target_Price < Opening_price) {
									for (int i = 0; i < 200; i++) {
										double a = (double) ((i + 1) * 0.01);
										DDDDD[i] = bitunix_system_only[16] + Open_wallet + bitunix_system_only[11] + bitunix_system_only[17] + (i + 1) + bitunix_system_only[18]
												+ Open_wallet * (i + 1) + bitunix_system_only[19]+ Target_Price +  bitunix_system_only[21] + bitunix_system_only[20]
												+ (Target_Price) * (i + 1) + bitunix_system_only[11] +"\n";
										DDDD = DDDD + DDDDD[i];

									}

									JOptionPane.showMessageDialog(null, bitunix_system_only[23]+ Target_Price + bitunix_system_only[21]+"\n" 
									+ bitunix_system_only[14]+ target_Price + bitunix_system_only[21]+"\n" + bitunix_system_only[22]);
		//---------------營利-----------------------//						 				 			  		
									try {
										DATA(DDDD,bitunix_system_only[24]);
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									double T = Target_Price / y;
									double TT = 0;
									double[] TTT = new double[(int) y];// 加入分成價格後價格
									double[] TTA = new double[(int) y];// 加入分成價格後價格
									String[] Data = new String[(int) y];
									String data = "";
									for (int i = 0; i < y; i = i + 1) {
										TT = TT + T;
										System.out.println("目標價格" + target_price + 
												" 加入分成價格" + (target_price - TT) + "元  "
												+ "   點位價獲利了" + TT + "元\n");
										
										Data[i] = bitunix_system_only[25] + target_price + bitunix_system_only[26]  + (target_price - TT) + bitunix_system_only[21] +  bitunix_system_only[27] 
												+ TT + bitunix_system_only[21]+"\n";
										TTT[i] = (target_price - TT);
										TTA[i] = TT;
										data = data + Data[i];

									}
									JOptionPane.showMessageDialog(null,
											bitunix_system_only[28] +"\n" + 
													 bitunix_system_only[29] +"\n"  +	 bitunix_system_only[30]  +
													y + 	 bitunix_system_only[31] +"\n" + 
													 bitunix_system_only[32] + target_Price	+
												 bitunix_system_only[21] +"\n" + bitunix_system_only[33] + 
									Target_Price + bitunix_system_only[21] +"\n" + data  );
		//---------------點位-----------------------//						
									try {
										DATA(data, bitunix_system_only[34]);
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									String[][] TEXT = new String[(int) y][200];
									JOptionPane.showMessageDialog(null,
											
											
											bitunix_system_only[35] + target_price + y + 
						"\n"+	bitunix_system_only[36] + Open_wallet + (bitunix_system_only[11] +bitunix_system_only[21] )
					+ "\n"+bitunix_system_only[37] + (Open_wallet / target_price) + bitunix_system_only[38]  + "\n"+bitunix_system_only[39] );
									// System.out.println("目標價格又稱
									// 預計我想入的點價位"+target_price+"我預計的合約資金"+Open_wallet+"usdt元"+"買入時換成該幣種"+(Open_wallet/target_price)+"多少數量");

									double quantity = Open_wallet / target_price; // 希望(小倉本金/目標點價格 )這時候目標價格下單 所以是數量 然後後到達 預計價格

									for (int i = 0; i < y; i++) {

										// System.out.println("目前防爆錢包"+A+"元 第"+(i+1)+"的"+"價位買入\n");

										for (int j = 0; j < 200; j++) {

											if ((quantity * TTA[i] * (j + 1)) < A) {

												// System.out.println("小於防爆錢包不顯示 第"+(i+1)+"的"+"價位"+
												// TTT[i]+"元"+"賣進的"+(j+1)+"倍數"+" 可獲利的"+
												// TTA[i]+"元"+"加上槓桿收益"+(TTA[i]*(j+1))+"元"+"最後加入數量*槓桿*獲利價"+(quantity*TTA[i]*(j+1))+"元\n");

												TEXT[i][j] = bitunix_system_only[40] + A +bitunix_system_only[41] + (i + 1) + bitunix_system_only[42]+ TTT[i] + bitunix_system_only[21] 
														+ bitunix_system_only[43]+ (j + 1) + bitunix_system_only[44] + "      "+bitunix_system_only[45] + TTA[i] +bitunix_system_only[21]  + bitunix_system_only[46]
														+ (TTA[i] * (j + 1)) + bitunix_system_only[21]  + bitunix_system_only[47]
														+ (quantity * TTA[i] * (j + 1)) + bitunix_system_only[21] +"\n";

											} else {
												TEXT[i][j] = "";

											}
										}
										System.out.println("\n");
									}

									String content = "";

									for (int i = 0; i < y; i++) {

										for (int j = 0; j < 200; j++) {

											content = content + TEXT[i][j];
										}
									}

									try {
										DATA(content, "最終要出入買賣");
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}

								} else {
									JOptionPane.showMessageDialog(null, bitunix_system_only[48]+ Target_Price);
								}

							}
							

						}
						
	// --------------------------------------------------------------------//// --------------------------------------------------------------------//// --------------------------------------------------------------------//		
						
						/*
						 * 我該保留多少U 避免爆倉
看漲價位 先轉貨幣本位系統 買單 做多
看下跌價格後反漲價格 往上做多
我們講可用倉位錢包
我們分成
次

*/
						
						if (Opening_price > target_price) {

							// 漲幅比較
							String[] gender1 = { bitunix_system_only[49] + A,
									bitunix_system_only[50]+"\n", 
									bitunix_system_only[51]+"\n",
									bitunix_system_only[52] + A + bitunix_system_only[11] +
									bitunix_system_only[53] + y +bitunix_system_only[54]+"\n" };
							
							
							double XX = Opening_price - target_price;
							double Open_wallet = A / y;
							double result_sqrt = 200 / y;
							double[] Result_sqrt = new double[(int) y];
							String[] Gender = new String[(int) y];
							String GGender = "";
							for (int i = 0; i < y; i++) {
								Gender[i] = bitunix_system_only[58]  + (i + 1) + 
										bitunix_system_only[59] + Open_wallet + 
										bitunix_system_only[11] +
										bitunix_system_only[60]  + (result_sqrt * (i + 1))
										+ 		bitunix_system_only[61] +"\n";
								GGender = GGender + Gender[i];
								Result_sqrt[i] = result_sqrt * (i + 1);
							}

							JOptionPane.showMessageDialog(null,
									gender1[0] + "\n" + gender1[1] + gender1[2] + gender1[3] + GGender, TranslateSystem[3],
									JOptionPane.INFORMATION_MESSAGE);

							// --------------------------------------------------------------------//
							int mType = JOptionPane.INFORMATION_MESSAGE;
							String in1 = JOptionPane.showInputDialog(null, bitunix_system_only[62], bitunix_system_only[14], mType);
							double target_Price = Double.parseDouble(in1);// 預計目標價格
							double Target_Price = (target_Price - target_price);// 我要獲利之間價差
							if (in1 == null) {
								JOptionPane.showMessageDialog(null, "關閉 ");
							} else {
								String[] DDDDD = new String[200];
								String DDDD = "";
								if (target_Price > Opening_price) {
									for (int i = 0; i < 200; i++) {
										double a = (double) ((i + 1) * 0.01);
										DDDDD[i] = bitunix_system_only[63] + Open_wallet + bitunix_system_only[11] +  bitunix_system_only[64] + (i + 1)
												+  bitunix_system_only[65]
												+ Open_wallet * (i + 1) + bitunix_system_only[66]  + Target_Price + bitunix_system_only[21] + bitunix_system_only[67] 
												+ (Target_Price) * (i + 1) + bitunix_system_only[11]+"\n";
										DDDD = DDDD + DDDDD[i];

									}

									JOptionPane.showMessageDialog(null, bitunix_system_only[68] + target_Price + bitunix_system_only[21]+"\n" +  bitunix_system_only[69] 
											+ Target_Price +  bitunix_system_only[21]+"\n" +  bitunix_system_only[70] );
		//---------------營利-----------------------//						 				 			  		
									try {
										DATA(DDDD, "營利可能");
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}

									double T = Target_Price / y;
									double TT = 0;
									double[] TTT = new double[(int) y];// 加入分成價格後價格
									double[] TTA = new double[(int) y];// 加入分成價格後價格
									String[] Data = new String[(int) y];
									String data = "";
									for (int i = 0; i < y; i = i + 1) {
										TT = TT + T;
										System.out.println(bitunix_system_only[71] + target_price + bitunix_system_only[72] + (target_price + TT) +  bitunix_system_only[21]
												+ "   點位價獲利了" + TT +  bitunix_system_only[21]+"\n");
										
										
										
										Data[i] = bitunix_system_only[71]+ target_price +bitunix_system_only[72] + (target_price + TT) + bitunix_system_only[21] + bitunix_system_only[73]
												+ TT +  bitunix_system_only[21]+"\n";
										TTT[i] = (target_price + TT);
										TTA[i] = TT;
										data = data + Data[i];

									}
									JOptionPane.showMessageDialog(null,
											bitunix_system_only[74]+"\n" + bitunix_system_only[75]+"\n" +  bitunix_system_only[76] + y +bitunix_system_only[77] +"\n" + bitunix_system_only[78] + target_Price
													+  bitunix_system_only[21]+"\n" + bitunix_system_only[79] + Target_Price +  bitunix_system_only[21]+"\n" + data);
		//---------------點位-----------------------//						
									try {
										DATA(data, "點位");
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									String[][] TEXT = new String[(int) y][200];
									JOptionPane.showMessageDialog(null,
											bitunix_system_only[80] + target_price + y + "\n"
									             +	bitunix_system_only[81] + Open_wallet + bitunix_system_only[11]+ bitunix_system_only[21]
													+ "\n"
									             +bitunix_system_only[82]+ (Open_wallet / target_price)
									             + bitunix_system_only[83] +
									             "\n"+bitunix_system_only[84]);
									// System.out.println("目標價格又稱
									// 預計我想入的點價位"+target_price+"我預計的合約資金"+Open_wallet+"usdt元"+"買入時換成該幣種"+(Open_wallet/target_price)+"多少數量");

									double quantity = Open_wallet / target_price; // 希望(小倉本金/目標點價格 )這時候目標價格下單 所以是數量 然後後到達 預計價格

									for (int i = 0; i < y; i++) {

										// System.out.println("目前防爆錢包"+A+"元 第"+(i+1)+"的"+"價位買入\n");

										for (int j = 0; j < 200; j++) {

											if ((quantity * TTA[i] * (j + 1)) < A) {

												// System.out.println("小於防爆錢包不顯示 第"+(i+1)+"的"+"價位"+
												// TTT[i]+"元"+"賣進的"+(j+1)+"倍數"+" 可獲利的"+
												// TTA[i]+"元"+"加上槓桿收益"+(TTA[i]*(j+1))+"元"+"最後加入數量*槓桿*獲利價"+(quantity*TTA[i]*(j+1))+"元\n");

												TEXT[i][j] = bitunix_system_only[85]+ bitunix_system_only[86] + (i + 1) + bitunix_system_only[87] + bitunix_system_only[88] + TTT[i] +  bitunix_system_only[21]+bitunix_system_only[89]
														+ (j + 1) + bitunix_system_only[90] + bitunix_system_only[91] + TTA[i] +  bitunix_system_only[21] + bitunix_system_only[92]
														+ (TTA[i] * (j + 1)) +  bitunix_system_only[21] + bitunix_system_only[93]
														+ (quantity * TTA[i] * (j + 1)) +  bitunix_system_only[21]+"\n";

											} else {
												TEXT[i][j] = "";

											}
										}
										System.out.println("\n");
									}

									String content = "";

									for (int i = 0; i < y; i++) {

										for (int j = 0; j < 200; j++) {

											content = content + TEXT[i][j];
										}
									}

									try {
										DATA(content, "最終營利要出入買賣");
										Runtime.getRuntime().exec("explorer.exe /, " + "Data\\");

									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}

								} else {
									JOptionPane.showMessageDialog(null, bitunix_system_only[94] + Target_Price);
								}

							}
							// --------------------------------------------------------------------//

						}

					
	
				
							
					}
				});
		     
	 //------------------JButton----menu------------------------------//   	     
		 
	     JButton b2=new JButton(bitunix_system_only[1]);   //   menu 
	   //  b2.setBounds(100,100,80,30);    
	     b2.setForeground(getColor);
	     b2.setBackground(Color.white);   
	     b2.setBounds(400,10,100,25);    
	//     b2.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//	     b2.setBorderPainted(false); // 移除邊框
	     b2.setFocusPainted(false); // 移除焦點框
	     menu.add(b2); 

	         
	         //   menu 

	         b2.addActionListener(new ActionListener() { 
					public void actionPerformed(ActionEvent e) {

						
						try {
							AIS.main_start();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
						
						
						f.dispose();
				
						
						
	
						main_min main_min=new main_min();
						
						
						try {
			
							main_min.man();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
								| InterruptedException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
						
					
					
					
				
			
					
				
				
					}
				});
				

		return menu;
    }
    
	public static JPanel Panel() throws IOException {
		
	       
			 JPanel panel=new JPanel(); 
		     panel.setBounds(0,0,w/3-20,h); //位置  // 大小  
		   //  panel.setBackground(Color.yellow);
		     panel.setBackground(getColor );

		       
		//------------------JPanel.wsie----------------------------------//   
		
		     
		      String m=  "<html><h2 style='color:white;'>"
		      		+ TranslateSystem[3] //Artificial intelligence
		      		+ "<i>!"
		      		+ "</h2><br><br><br><br><h2 style='color:white'> "
		      		+  bitunix_system_only[0]//ANN
		      		+ "</h2></html>";
		     
		     JLabel   music_wise= new JLabel(m); 
		     music_wise.setForeground(new Color(254,186,41)); // 設置文字顏色為紅色
		     panel.add(music_wise); 
		       


	 //------------------------------------------------------//
		     
		     
		     JButton b0=new JButton(bitunix_system_only[3]);     //Algorithm information

		       
		     b0.setBounds(150,10,100,25);  
		     b0.setForeground(getColor);
		     b0.setBackground(Color.white);  
//		     b1.setContentAreaFilled(false); // 取消填充，使按鈕背景透明
//		     b2.setBorderPainted(false); // 移除邊框
		     b0.setFocusPainted(false); // 移除焦點框
		     panel.add(b0);
		     
		     //------  //Algorithm information-----------//
	         
	         b0.addActionListener(new ActionListener() { //  //Algorithm information
				public void actionPerformed(ActionEvent e) {

					try {
						AIS.main_start();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
							| InterruptedException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					  
					AIS.chome(UELname);
			
			
					
					
					
					
				}
			});
	         
	         //------------------------------------------------------//

		
	       
         return panel;
	}
	public static JPanel Frame_Panel() throws IOException {

	     
				//---------------Frame_Panel----------------------//

		
				 JPanel Frame_Panel=new JPanel();  
				 Frame_Panel.setBounds(w/3-20,0,w-w/3+5,h-h/11); //位置  // 大小   // 撿到側邊欄位W  跟  menu底下欄位H
			   //  panel.setBackground(Color.yellow);
				 Frame_Panel.setBackground(Color.white );
			          Frame_Panel.setLayout(null); 
		       
		       
			     
					//---------------Frame_Panel.wise----------------------//
		       
				 String Frame_Panel_name=  "<html><h2 style='color:rgb(0,183,100);'>"
				 		+ TranslateSystem[3] // AIS 標題系統
				 				+"<br>"+"<br>"
				 		+  bitunix_system_only[0] // 系統 名稱
				 		+ "</h2>"
				 		+ "<h2>"
				 		+ TranslateSystem[6]// 左邊標語
				 		+ "</h2>"
				 		+ "</html>";
			     JLabel   music_wise2= new JLabel( Frame_Panel_name); 
			     music_wise2.setForeground(new Color(254,186,41)); // 設置文字顏色
			     music_wise2.setBounds(10,20,500,200);  
			       
			     Frame_Panel.add(music_wise2); 
			//-------------------------------------------------------------//
			     /*
			
			     */
			     
			      int setColumns_wise=20;
			     
				     JPanel System=new JPanel();  
				     System.setBounds(10,20+200,500,500);  
				     System.setBackground(Color.white );//-----------------------System-------JPanel-------------//
				     System.setLayout(null); 
				     Frame_Panel.add(System); 
				  
			
					//-------------wallet-------------------------------//    
				     JLabel   wallet= new JLabel( bitunix_system_only[4]); 
				     wallet.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     wallet.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     wallet.setBounds((w/3-90)/2,-40,500,100);  
				     System.add(wallet); 
			    
				     
						//-------------wallet-------------------------------//    
				     JLabel   wallet2= new JLabel( bitunix_system_only[5]); 
				     wallet2.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     wallet2.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     wallet2.setBounds((w/3-90)/2,20,500,100);  
				     System.add(wallet2); 
				     
				     
				     

				     
				     
						//-------------several_portions-------------------------------//   
				     JLabel   several_portions= new JLabel( bitunix_system_only[6]); 
				     several_portions.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     several_portions.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     several_portions.setBounds((w/3-90)/2,70,500,100);  
				     System.add(several_portions); 
				     
				     
			          JFtxt[0] = new JTextField();
				        JFtxt[0].setColumns(setColumns_wise);
				        JFtxt[0].setBounds((w/3-90)/2,30,200,20);
				        System.add(JFtxt[0]);
				        
				        
			     
						//-------------several_portions-------------------------------//   
				     JLabel   several_portions2= new JLabel( bitunix_system_only[7]); 
				     several_portions2.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     several_portions2.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     several_portions2.setBounds((w/3-90)/2,147,500,100);  
				     System.add(several_portions2); 
					  //--------------------------------------------------------// 
			          JFtxt[1] = new JTextField();
			          JFtxt[1].setColumns(setColumns_wise);
				      JFtxt[1].setBounds((w/3-90)/2,80,200,20);
			        System.add(JFtxt[1]);
				     
						//-------------several_portions-------------------------------//   
				     JLabel   several_portions3= new JLabel( bitunix_system_only[8]); 
				     several_portions3.setForeground(AIS.ColorsetBackground_AIS); // 設置文字顏色
				     several_portions3.setFont(new Font("Arial", Font.BOLD, 15)); //字體大小 設定粗體
				     several_portions3.setBounds((w/3-90)/2,170,500,100);  
				     System.add(several_portions3); 
				     
				     
				     //------------------------------------------------------//
				     
			          JFtxt[2] = new JTextField();
			          JFtxt[2].setColumns(setColumns_wise);
				      JFtxt[2].setBounds((w/3-90)/2,135,200,20);
			        System.add(JFtxt[2]);
			        
			        


				     
			          JFtxt[3] = new JTextField();
			          JFtxt[3].setColumns(setColumns_wise);
				      JFtxt[3].setBounds((w/3-90)/2,235,200,20);
			        System.add(JFtxt[3]);
			        
			     
			     
			     
			     
				
			        
	 return Frame_Panel;
	}
	
	
    
    
	public static void main() throws IOException {

			  ResizeImageExample();
	
	}

	private static void ResizeImageExample() throws IOException {
		
		//---------------TranslateSystem---------------------------//
	     TranslateSystem =nat.read_System( );
		   
	     bitunix_system_only=nat.get_bitunix_system_only();
	     
	     
	     
		   //---------------------------------//
	
		 //---------------JFrame----------------------//
	    	 JFrame f= new JFrame( TranslateSystem[3]);  //標題
	        	String path = "AIS.jpg";
		     Image icon = Toolkit.getDefaultToolkit().getImage(path);
		       f.setIconImage(icon);
	//	       f.getContentPane().setBackground(Color.white);

		   	//------------------Frame_Panel----------------------------------//    
		       JPanel Frame_Panel =  Frame_Panel();
	
		//------------------JPanel----------------------------------//       
		   

		       JPanel panel =  Panel();
		       

		       //-----------------menu- ---------------------//	       
		       
		       JPanel menu =  menu(f);
		       
	     
	     //-----------------------------------------//
	     //-------------結尾-----------------------//     
         f.add(panel); 
         f.add(menu); 
         f.add( Frame_Panel);
	     //-----------JFrame------------------------//
         //----------------------------------//
	
	      f.setBounds(win_JFrameWidth,win_JFramegetHeight,w,h);    
          f.setLayout(null);    
          // 禁止調整視窗大小
          f.setResizable(false);
          f.setVisible(true);   
 
          
   
	}

	public static void DATA(String data, String namedata) throws IOException {
		FileWriter fw = new FileWriter("data.wise.🗄️\\illustrate\\" + namedata + ".txt");
		fw.write(data);// Public\Documents

		fw.flush();
		System.out.println("Suweizhe -存檔到公用文件系統!");
		// After used close.
		fw.close();

	}

	public static void Create_profile() throws IOException {
		try {
    	      File file = new File("data.wise.🗄️\\illustrate\\" + "營利" + ".txt");
    	      if (!Desktop.isDesktopSupported()) {
    	        System.out.println("not supported");
    	        return;
    	      }
    	      Desktop desktop = Desktop.getDesktop();
    	      if (file.exists())
    	        desktop.open(file);
    	    } catch (Exception e3) {
    	    	e3.printStackTrace();
    	    }        
	        
		try {
    	      File file = new File("data.wise.🗄️\\illustrate\\" + "最終要出入買賣" + ".txt");
    	      if (!Desktop.isDesktopSupported()) {
    	        System.out.println("not supported");
    	        return;
    	      }
    	      Desktop desktop = Desktop.getDesktop();
    	      if (file.exists())
    	        desktop.open(file);
    	    } catch (Exception e3) {
    	    	e3.printStackTrace();
    	    }           	  
		try {
    	      File file = new File("data.wise.🗄️\\illustrate\\" + "點位" + ".txt");
    	      if (!Desktop.isDesktopSupported()) {
    	        System.out.println("not supported");
    	        return;
    	      }
    	      Desktop desktop = Desktop.getDesktop();
    	      if (file.exists())
    	        desktop.open(file);
    	    } catch (Exception e3) {
    	    	e3.printStackTrace();
    	    }           	  
	  
		try {
    	      File file = new File("data.wise.🗄️\\illustrate\\" +  "營利可能" + ".txt");
    	      if (!Desktop.isDesktopSupported()) {
    	        System.out.println("not supported");
    	        return;
    	      }
    	      Desktop desktop = Desktop.getDesktop();
    	      if (file.exists())
    	        desktop.open(file);
    	    } catch (Exception e3) {
    	    	e3.printStackTrace();
    	    }  
		
		

	}
	
	
	
}
