import java.util.prefs.Preferences;

public class StartupApp {

	 public static void main(String[] args) {
	        // 設置註冊表條目，將應用程序添加到開機啟動
	     // 
		 
		 String path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";

		  Preferences prefs = Preferences.userRoot().node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
	        
	        String programName = "SystemTrayExample"; // 您的應用名稱
	   	
	        boolean exists = checkRegistryKeyExists(path, programName);
	   	 
	   	 
	   	 
	        String command = "C:\\Users\\zxc78\\OneDrive\\Desktop\\experimentalfield\\"+programName+".exe"; // EXE 程式的啟動命令
	        
	        // 將 EXE 路徑添加到 Windows 開機啟動
	        prefs.put(programName, command);
	        
	        // 確認是否成功設置
	        String existingCommand = prefs.get(programName, null);
	        System.out.println("程序設置為開機自啟動: " + existingCommand+"  exists   "+exists);
	    }
	 
	
	 private static boolean checkRegistryKeyExists(String path, String key) {
		 Preferences prefs = Preferences.systemRoot().node(path);
		 String[] keys = {};
		 try {
		 keys = prefs.keys();
		 } catch (Exception e) {
		 // Handle error
		 }
		 for (String k : keys) {
		 if (k.equals(key)) {
		 return true;
		 }
		 }
		 return false;

		 }

	
		 
}
