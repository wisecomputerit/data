import javax.swing.*;
import java.awt.event.*;
/*
public class MenuBoxJComboBox {

	public static void main(String[] args) {
		// TODO 自動產生的方法 Stub
	       // 創建主框架
        JFrame frame = new JFrame("Drop-down Menu Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        
        // 創建一個 JComboBox（下拉選單）
        String[] options = {"選項 1", "選項 2"};
        JComboBox<String> comboBox = new JComboBox<>(options);
        
        
        
        
        // 創建一個標籤來顯示選擇結果
        JLabel label = new JLabel("請選擇一個選項");
        
        
        
        
        // 為 comboBox 設置一個事件監聽器，當選擇發生改變時更新標籤
        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedOption = (String) comboBox.getSelectedItem();
                
                
                label.setText("你選擇了: " + selectedOption);
            }
        });
        
        // 布局設定
        JPanel panel = new JPanel();
        panel.add(comboBox);
        panel.add(label);
        
        // 將面板添加到框架中
        frame.add(panel);
        
        // 顯示框架
        frame.setVisible(true);
	}

}
*/

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import message.box.Message;

//---拖住按鈕移動//
public class MenuBoxJComboBox extends JFrame implements MouseListener, MouseMotionListener {
           


	JButton button2= new JButton("close");
		JButton button1= new JButton();
		
		JButton button0= new JButton();
		
	  JPanel panel=new JPanel();  
	  
	    JLabel   music_wise2= new JLabel( ); 
	    
	    static JFrame JFJF;
	    
	    JLabel label ;
        //JComboBox<String> comboBox;
	    
        
        JComboBox<String> comboBox= new JComboBox<>();
	    
int x0, y0;
int x3,y3;//记录鼠标拖动之前原来的鼠标位置的东东

       static String getMenuBox;
       
       static String return_name;
       
public static void OKMenuBox(String name)
{
	return_name=name;
	

}
       

public  MenuBoxJComboBox(String [] it,String OK,String Cancle,String close,String title,String All,Color color) throws IOException {
	

      button0.setText(OK);
	button1.setText(Cancle);

	button2.setText(close);
    JLabel   music_wise= music_wise2;

	

	 JFrame JF= this;  		
		
	 JFJF=JF;
	    //-----------------------------------------------//
		// TODO Auto-generated method stub
		
	 /*
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
       File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	     
	     JF.setIconImages(icons); 
	     
	     */
		 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

		 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
		 JF. setLayout(new FlowLayout());
		 JF.setTitle("java");
		 
		
		//     JF.setBounds(100, 100, 400, 400); 
		         
//		 JF.setIconImages(icons); 
//		 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//		 JF.setBounds(300, 200, 200, 200);
//		 JF.setSize(250,130);    
		 JF.setLayout(null);    
			java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	     //----------------JPanel-------------------------------//
			
			int width = ((scr_size.width - 300/2) / 2);
			
			int height = ((scr_size.height - 150/2)/2);
			
			
			int setpanelwidth=110;
	   
			int setpanelheight=120;
		
	     panel.setBounds(width-20-setpanelwidth/2,height-setpanelheight/2,300/2+20+setpanelwidth,(150/2)+setpanelheight);    
	 //    JF.setContentPane(panel);
	     panel.setBackground(Color.gray);  
	 	Color bgColor = new Color(243,243,243);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	 	panel.setBackground(bgColor);
		Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
		panel.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));
		
		panel.setLayout(null);
		
		//--------------------//
		

		   //  music_wise2.setForeground(new Color(254,186,41)); // 設置文字顏色

 	
		
	     int W=50;
	     int H=20;
	     
	
	    

		//---------------------------------------------//
	
        
        
	     // 創建一個 JComboBox（下拉選單）
	        String[] options = it;

	
	        
	        for (String item : options) {
	            comboBox.addItem(item);
	        }

	        
	        comboBox.setBounds(width-10, height+80/2, setpanelwidth+setpanelwidth-70, 20); 
	        
	        
	        
	  
	         label = new JLabel(title);      //  標籤
	        
	        label.setBounds(width-30, height+10/2, setpanelwidth+setpanelwidth, 20); 
	        
	        
	        // 為 comboBox 設置一個事件監聽器，當選擇發生改變時更新標籤
	        comboBox.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String selectedOption = (String) comboBox.getSelectedItem();
	                
	                
	                label.setText(All+" :  " + selectedOption);
	                
	           	   getMenuBox=selectedOption;
	                
	            }
	        });
        
	        JF.add(comboBox);
	        JF.add(label);
	        
        
    
     
        

        // 将 JPanel 放入 JScrollPane，使其具有滚动条
 /*       JScrollPane scrollPane = new JScrollPane(menuPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
*/
        // 将 JScrollPane 添加到窗口的顶部
     //   panel.add(scrollPane, BorderLayout.NORTH);
        
    //----------------------------------------------//
        

	
	    
        
        
		

	     
	     
        
        
        
        

	     //----獨立確認--------Click-------------------------/
	  //   JButton jButton   = new JButton("Click"); 

		button1.setBounds(width+100-10, height+80, 50, 20); 
	     JF.add(button1);
	  //   jButton.setBackground(new Color(203,0,66));   
	     button1.setFocusable(false);	
	     button1.setHorizontalTextPosition(button1.CENTER);
	     button1.setVerticalTextPosition(button1.BOTTOM);
	     button1.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	     button1.setIconTextGap(-20); //位置 		
	     button1.setForeground(Color.white);
	     button1.setBackground(color );
	     button1.setBorder(BorderFactory.createEtchedBorder());
	     JF.add(button1);
	     
	     
	     //-------------------------------------------//
	     
	 	button0.setBounds(width-10, height+80, 50, 20); 
	     JF.add(button0);
	  //   jButton.setBackground(new Color(203,0,66));   
	     button0.setFocusable(false);	
	     button0.setHorizontalTextPosition(button1.CENTER);
	     button0.setVerticalTextPosition(button1.BOTTOM);
	     button0.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
	     button0.setIconTextGap(-20); //位置 		
	     button0.setForeground(Color.white);
	     button0.setBackground(color );
	     button0.setBorder(BorderFactory.createEtchedBorder());
	     JF.add(button0);
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     
	     //-------獨立--------close----------------------/
	     
	  //   JButton button2 = new JButton();
	     button2.setBounds(width+165, height-60, 40, 18);
			JF.add(button2);
			
			//	data.addActionListener((ActionListener) this);
	//		button2.setText("close");
			button2.setFocusable(false);	
			button2.setHorizontalTextPosition(button2.CENTER);
			button2.setVerticalTextPosition(button2.BOTTOM);
			button2.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
			button2.setIconTextGap(-20); //位置 		
			button2.setForeground(Color.white);
			button2.setBackground(color );
			button2.setBorder(BorderFactory.createEtchedBorder());
			JF.add(button2);
			//---------------------//
			
	
			

			button0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
			
				     String name_n=getMenuBox;
				     
					if(getMenuBox==null)
					{
						name_n =it[0];
						
				
					}
					

					return_name=name_n;
					 System.out.print("GGGGGGGGGGGGGGGGetMenuBox = "+return_name+"\n");
			
					 try {
							getMenuBox(return_name);
						} catch (IOException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
		
					
					 Translate T =  new Translate();
			
					 

					try {
						Translate.man();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException
							| InterruptedException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
				
				
					 try {
							getMenuBox(return_name);
						} catch (IOException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
		
					String in3="";
					MenuBoxJComboBox.OKMenuBox(in3);
				
					
					
					JFJF.dispose();
					JF.dispose();
					
				
				}
			});
	//--------------------------------------------------//			
	     
	 	
			button2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
				   	
	            	try {
						AIS.main_option();
					} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
						// TODO 自動產生的 catch 區塊
						e1.printStackTrace();
					}
					// System.exit(0);
			//	JF.setExtendedState(JFrame.ICONIFIED);
					JF.dispose();
				}
			});
	     
	//---------------------------jButton----Click-----------------------------------------------//	     
			 
	     
			button1.addActionListener(new ActionListener() { 
		            // Anonymous class. 
		  
		            public void actionPerformed(ActionEvent e) 
		            { 
		                // Override Method 
		  
		                // Declaration of String class Objects. 
		            	
		               	
		            	try {
							AIS.main_option();
						} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
							// TODO 自動產生的 catch 區塊
							e1.printStackTrace();
						}
		                String qual = " "; 
		                //---------music----------------//
		                // If condition to check if jRadioButton2 is selected. 
		                String op="開";
		             	String closure="關";
		             	
		             	
		       
		                // MessageDialog to show information selected radio buttons. 
		            	JF.dispose();
		            } 
		        }); 
			
	//-----------------------------------------------------------------------//		
			
			  
			
			//-----------------------------------------------------//
	   
	


/*


button1.setBackground(Color.gray);  
Color bgColor = new Color(70,165,165);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
button1.setBackground(bgColor);
Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
button1.setBorder(BorderFactory.createTitledBorder(genderLine, "System"));

*/


			panel.addMouseListener(this);
			panel.addMouseMotionListener(this);//添加监视器

			
			
			
setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

setUndecorated(true);// 窗口去边框
setBackground(new Color(0,0,0,0));// 设置窗口为透明色   

add(panel);
setVisible(true);
setResizable(false);//设置大小不可调节




}



public void mouseEntered(MouseEvent e) {}

public void mouseReleased(MouseEvent e) {}






public void mousePressed(MouseEvent e){//记录鼠标拖动之前原来的鼠标位置的东东
x3 = e.getX();
y3 = e.getY();
}




public void mouseClicked(MouseEvent e) {}





public void mouseExited (MouseEvent e) {}

         public void mouseDragged(MouseEvent e) {
        	 
        	 
        	 
        	 
        	    
              /*
   
        	 
           	*/
        	 
       	  x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int x1=button1.getBounds().x;// 获取按钮坐标
       	  int y1 = button1.getBounds().y;
       	  button1.setLocation(x0 + x1 - x3, y0 + y1 - y3);

       	  
       	  
       	  int X1=button2.getBounds().x;// 获取按钮坐标
       	  int Y1 = button2.getBounds().y;
       	  button2.setLocation(x0 + X1 - x3, y0 + Y1 - y3);
       	  
       	  
     	  
       	  int X1X=button0.getBounds().x;// 获取按钮坐标
       	  int Y1Y = button0.getBounds().y;
       	  button0.setLocation(x0 + X1X - x3, y0 + Y1Y - y3);
       	  
       	  
          	  
          x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int XX1=panel.getBounds().x;// 获取按钮坐标
       	  int YY1 = panel.getBounds().y;
       	  panel.setLocation(x0 + XX1 - x3, y0 + YY1 - y3);
       	  

       	  
       	  
          x0=e.getX();//获取拖动后的鼠标坐标
       	  y0 = e.getY();
       	  int XXX1=music_wise2.getBounds().x;// 获取按钮坐标
       	  int YYY1 = music_wise2.getBounds().y;
       	music_wise2.setLocation(x0 + XXX1 - x3, y0 + YYY1 - y3);
       	  
       	  

        
   	  int x1x=label.getBounds().x;// 获取按钮坐标
   	  int y1x = label.getBounds().y;
   	 label.setLocation(x0 + x1x - x3, y0 + y1x - y3);
	    

  	  int x1Y=comboBox.getBounds().x;// 获取按钮坐标
  	  int y1Y = comboBox.getBounds().y;
  	comboBox.setLocation(x0 + x1Y - x3, y0 + y1Y - y3);

}

         public void mouseMoved(MouseEvent e) {}
         
         public static String  getMenuBox(String Name) throws IOException {
        		
        		String name =Name;
        		if(name==null)
        		{
        			name="";
        		}
        
        		return name;
        	}        
public static String  setMenuBox(String [] it,String OK,String Cancle,String close,String title,String All,Color color) throws IOException {
	
       //        	Color color=new Color(203,0,66);
      //          String[] menuItems = {"Open", "Save", "Close", "Exit"};
                  new MenuBoxJComboBox(it,OK,Cancle,close,title,All,color);// GA
	
                 System.out.print("setMenuBox    " +MenuBoxJComboBox.getMenuBox(return_name));

 		
                  
                // JFJF
                 return getMenuBox(return_name);

}




public static void  Demo(String close_add ,String Click ,String System) throws IOException 
{ 
  //---------加入文章------------------------------//
	//word_Demo
	

	



	
	
	
	
	
	

   //-----------------------------------------------//
	// TODO Auto-generated method stub
	 JFrame JF= new JFrame();    
	 JF.setExtendedState(JFrame.MAXIMIZED_BOTH); // 全螢幕

	 JF. setDefaultCloseOperation(EXIT_ON_CLOSE);
	 JF. setLayout(new FlowLayout());
	 JF.setTitle("java");
	 
	    final List<Image> icons = new ArrayList<Image>();
	    
	      String imagePath = "AIS.jpg";
        File imageFile = new File(imagePath);
	     icons.add(ImageIO.read(imageFile));
	//     JF.setBounds(100, 100, 400, 400); 
	         
//	 JF.setIconImages(icons); 
//	 JF.getContentPane().setBackground( new Color(254,249,169)); // ---       顏色
//	 JF.setBounds(300, 200, 200, 200);
//	 JF.setSize(250,130);    
	 JF.setLayout(null);    
		java.awt.Dimension scr_size =java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    //----------------JPanel-------------------------------//
		
		int width = ((scr_size.width - 300/2) / 2);
		
		int height = ((scr_size.height - 150/2)/2);
		
		
		
    JPanel panel=new JPanel();  
    panel.setBounds(width-20,height,300/2+20,(150/2));    
//    JF.setContentPane(panel);
    panel.setBackground(Color.gray);  
	Color bgColor = new Color(254,249,169);//背景顏色//https://www.ginifab.com.tw/tools/colors/color_picker_from_image.php
	panel.setBackground(bgColor);
	Border genderLine = BorderFactory.createLineBorder(Color.BLACK); // 框框顏色
	panel.setBorder(BorderFactory.createTitledBorder(genderLine, System));
    
	//---------------------------------------------//
	

	

	

    

    //----獨立確認--------Click-------------------------/
    JButton jButton   = new JButton(Click); 

  jButton.setBounds(width+50, height+40, 50, 20); 
  JF.add(jButton);
 //   jButton.setBackground(new Color(203,0,66));   
    jButton.setFocusable(false);	
    jButton.setHorizontalTextPosition(jButton.CENTER);
    jButton.setVerticalTextPosition(jButton.BOTTOM);
    jButton.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
    jButton.setIconTextGap(-20); //位置 		
    jButton.setForeground(Color.white);
    jButton.setBackground(new Color(203,0,66) );
    jButton.setBorder(BorderFactory.createEtchedBorder());
    JF.add(jButton);
    
    //-------獨立--------close----------------------/
    
    JButton close = new JButton();
		close.setBounds(width+110, height, 40, 18);
		JF.add(close);
		
		//	data.addActionListener((ActionListener) this);
		close.setText(close_add);
		close.setFocusable(false);	
		close.setHorizontalTextPosition(close.CENTER);
		close.setVerticalTextPosition(close.BOTTOM);
		close.setFont(new Font("Comic Sans",Font.BOLD,12));//大小
		close.setIconTextGap(-20); //位置 		
		close.setForeground(Color.white);
		close.setBackground(new Color(203,0,66) );
		close.setBorder(BorderFactory.createEtchedBorder());
		JF.add(close);
		
//--------------------------------------------------//			
    
	
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				// System.exit(0);
		//	JF.setExtendedState(JFrame.ICONIFIED);
				JF.dispose();
			}
		});
    
//---------------------------jButton----Click-----------------------------------------------//	     
		 
    
		  jButton.addActionListener(new ActionListener() { 
	            // Anonymous class. 
	  
	            public void actionPerformed(ActionEvent e) 
	            { 
	                // Override Method 
	  
	                // Declaration of String class Objects. 
	                String qual = " "; 
	                //---------music----------------//
	                // If condition to check if jRadioButton2 is selected. 
	                String op="開";
	             	String closure="關";
	             	
	             	
	       
	                // MessageDialog to show information selected radio buttons. 
	            	JF.dispose();
	            } 
	        }); 
		
//-----------------------------------------------------------------------//		
		
		  
		
		//-----------------------------------------------------//
  
  JF.setUndecorated(true);// 窗口去边框
	JF.setBackground(new Color(0,0,0,0));// 设置窗口为透明色 
	  JF.add(panel);
    JF.setVisible(true);            
} 







}










