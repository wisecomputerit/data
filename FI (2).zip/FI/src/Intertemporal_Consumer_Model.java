
public class Intertemporal_Consumer_Model {

}
